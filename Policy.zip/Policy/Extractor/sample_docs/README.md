# Sample Docs Placeholder

- Add small PDF/DOCX/HTML/MD files here for testing.
- Expected outputs should live alongside tests (golden `policies.jsonl` + index).
