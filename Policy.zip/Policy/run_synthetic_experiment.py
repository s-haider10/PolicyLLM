﻿#!/usr/bin/env python3
"""
run_synthetic_experiment.py — Full pipeline experiment with synthetic data

Flow:
  1. Extract  — explicit_policy.md → explicit policies (LLM)
  2. Implicit — decision_log.csv → implicit policies (FP-Growth)
  3. Merge    — explicit + implicit → merged_policies.json
  4. Validate — merged_policies.json → compiled_policy_bundle.json (Z3)
  5. Enforce  — bundle + test_queries → enforcement_results.json (LLM + Z3)

Usage:
    echo "OPENAI_API_KEY=sk-..." > .env
    python run_synthetic_experiment.py --all
"""
import argparse
import csv
import json
import os
import shutil
import sys
import time
from pathlib import Path
from datetime import datetime

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

sys.path.insert(0, str(Path(__file__).parent))

SYNTHETIC_DIR = Path("Evaluation/data/synthetic")
OUTPUT_DIR = Path("Evaluation/results/synthetic_run")
EXPLICIT_POLICY = SYNTHETIC_DIR / "explicit_policy.md"
IMPLICIT_LOG = SYNTHETIC_DIR / "implicit_decision_log.csv"
IMPLICIT_GT = SYNTHETIC_DIR / "implicit_ground_truth.json"
TEST_QUERIES = SYNTHETIC_DIR / "test_queries.jsonl"


# ======================================================================
# STEP 1: EXTRACT — explicit_policy.md → explicit policies
# ======================================================================
def step_extract():
    from Extractor.src.config import load_config
    from Extractor.src import pipeline

    print("=" * 70)
    print("STEP 1: EXTRACT — explicit_policy.md → explicit_policies.json")
    print("=" * 70)

    extract_dir = OUTPUT_DIR / "extraction"
    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    extract_dir.mkdir(parents=True)

    config = load_config("Extractor/configs/config.chatgpt.yaml")

    print(f"Input:  {EXPLICIT_POLICY}")
    print(f"Model:  {config.llm.provider}/{config.llm.model_id}")
    print()
    print("  Pass 1: Classify sections (policy vs non-policy)")
    print("  Pass 2: Extract components (conditions/actions/exceptions)")
    print("  Pass 3: Extract entities ($500, 30 days, GDPR)")
    print("  Pass 4: Merge duplicates")
    print("  Pass 5: Attach metadata (owner/date/domain/regulatory)")
    print("  Pass 6: Validate completeness")
    print()

    t0 = time.time()
    pipeline.run_pipeline(
        input_path=str(EXPLICIT_POLICY),
        output_dir=str(extract_dir),
        tenant_id="techmart",
        batch_id=f"synth_{datetime.now().strftime('%H%M%S')}",
        config=config,
    )
    elapsed = time.time() - t0

    jsonl_files = list(extract_dir.glob("*.jsonl"))
    if not jsonl_files:
        print("ERROR: No policies extracted!")
        return []

    policies = []
    with open(jsonl_files[0], encoding="utf-8") as f:
        for line in f:
            if line.strip():
                policies.append(json.loads(line))

    print(f"Extracted {len(policies)} explicit policies in {elapsed:.1f}s")
    for p in policies:
        pid = p.get("policy_id", "?")
        domain = p.get("metadata", {}).get("domain", "?")
        n_cond = len(p.get("conditions", []))
        print(f"  {pid}: domain={domain}, conditions={n_cond}")

    for p in policies:
        p["origin"] = "explicit"

    out_path = OUTPUT_DIR / "explicit_policies.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(policies, f, indent=2)
    print(f"\nOutput: {out_path}")
    return policies


# ======================================================================
# STEP 2: IMPLICIT — decision_log.csv → discovered rules
# ======================================================================
def step_implicit():
    print()
    print("=" * 70)
    print("STEP 2: IMPLICIT — decision_log.csv → implicit_policies.json")
    print("=" * 70)

    with open(IMPLICIT_LOG, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    print(f"Input:  {IMPLICIT_LOG} ({len(rows)} rows)")

    try:
        from mlxtend.frequent_patterns import fpgrowth, association_rules
        from mlxtend.preprocessing import TransactionEncoder
        import pandas as pd
    except (ImportError, AttributeError) as e:
        if "ARRAY_API" in str(e) or "NumPy" in str(e):
            print("NumPy version conflict. Fix with:")
            print("  pip install numpy<2")
            print("  OR: pip install --upgrade pandas numexpr bottleneck")
            print("\nFalling back to ground truth rules...")
        else:
            print("mlxtend not installed — using ground truth as fallback")
        return _fallback_implicit()

    # Discretize
    transactions = []
    for r in rows:
        items = set()
        items.add(f"tier={r['customer_tier']}")
        items.add(f"cat={r['product_category']}")
        items.add(f"receipt={r['has_receipt']}")
        items.add(f"decision={r['decision']}")
        items.add(f"refund={r['refund_type']}")
        items.add(f"escalated={r['escalated']}")

        days = int(r['days_since_purchase'])
        if days <= 2:     items.add("days=0-2")
        elif days <= 15:  items.add("days=3-15")
        elif days <= 30:  items.add("days=16-30")
        elif days <= 60:  items.add("days=31-60")
        else:             items.add("days=61+")

        amount = float(r['order_amount'])
        if amount <= 500: items.add("amount<=500")
        else:             items.add("amount>500")

        transactions.append(list(items))

    te = TransactionEncoder()
    te_ary = te.fit_transform(transactions)
    df = pd.DataFrame(te_ary, columns=te.columns_)
    freq = fpgrowth(df, min_support=0.03, use_colnames=True)
    # mlxtend >= 0.21 requires num_itemsets parameter
    try:
        rules = association_rules(freq, metric="confidence", min_threshold=0.85,
                                  num_itemsets=len(df))
    except TypeError:
        rules = association_rules(freq, metric="confidence", min_threshold=0.85)

    decision_cols = {"decision=approve", "decision=deny",
                     "refund=full_refund", "refund=store_credit", "refund=none",
                     "escalated=True", "escalated=False"}
    input_cols = set(te.columns_) - decision_cols

    discovered = []
    for _, rule in rules.iterrows():
        ant = set(rule["antecedents"])
        con = set(rule["consequents"])
        if ant.issubset(input_cols) and con.issubset(decision_cols):
            discovered.append({
                "antecedent": sorted(ant),
                "consequent": sorted(con),
                "support": round(float(rule["support"]), 4),
                "confidence": round(float(rule["confidence"]), 4),
                "lift": round(float(rule["lift"]), 2),
            })

    # Prune: if rule A ⊂ rule B with same consequent, keep only A (more general)
    pruned = []
    discovered.sort(key=lambda r: len(r["antecedent"]))  # shortest first
    for rule in discovered:
        ant = set(rule["antecedent"])
        con = tuple(rule["consequent"])
        # Check if a more general rule (subset antecedent, same consequent) already exists
        is_redundant = False
        for kept in pruned:
            if tuple(kept["consequent"]) == con and set(kept["antecedent"]).issubset(ant):
                is_redundant = True
                break
        if not is_redundant:
            pruned.append(rule)

    # Keep only high-confidence rules with meaningful lift
    pruned = [r for r in pruned if r["confidence"] >= 0.90 and r["lift"] >= 1.1]
    pruned.sort(key=lambda r: (r["confidence"], r["lift"]), reverse=True)

    # Cap at top 30
    pruned = pruned[:30]

    print(f"\nDiscovered {len(discovered)} raw rules → pruned to {len(pruned)}")
    for r in pruned[:10]:
        ant = " AND ".join(r["antecedent"])
        con = " AND ".join(r["consequent"])
        print(f"  {ant}  =>  {con}  (conf={r['confidence']:.2f}, lift={r['lift']:.1f})")

    with open(OUTPUT_DIR / "fpgrowth_raw_rules.json", "w", encoding="utf-8") as f:
        json.dump(discovered, f, indent=2)

    implicit_policies = _convert_rules_to_stage1(pruned)

    out_path = OUTPUT_DIR / "implicit_policies.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(implicit_policies, f, indent=2)
    print(f"\nConverted to {len(implicit_policies)} implicit policies (Stage 1 JSON)")
    print(f"Output: {out_path}")
    return implicit_policies


def _parse_item(item):
    """Parse FP-Growth item like 'tier=Gold', 'amount>500', 'amount<=500'."""
    # Handle amount>500, amount<=500 (no = separator)
    if item.startswith("amount>"):
        return "amount", item[len("amount"):]     # ">500"
    if item.startswith("amount<="):
        return "amount", item[len("amount"):]     # "<=500"
    if "=" in item:
        return item.split("=", 1)
    return item, ""


def _convert_rules_to_stage1(discovered_rules):
    policies = []
    seen = set()

    for i, rule in enumerate(discovered_rules):
        conditions = []
        for item in rule["antecedent"]:
            key, val = _parse_item(item)
            if key == "tier":
                conditions.append({"type": "customer_tier", "value": val, "operator": "=="})
            elif key == "cat":
                conditions.append({"type": "product_category", "value": val, "operator": "=="})
            elif key == "receipt":
                conditions.append({"type": "boolean_flag", "parameter": "has_receipt", "value": val == "True"})
            elif key == "days":
                if val == "61+":
                    conditions.append({"type": "time_window", "value": 60, "operator": ">"})
                elif val == "31-60":
                    conditions.append({"type": "time_window", "value": 60, "operator": "<="})
                elif val == "16-30":
                    conditions.append({"type": "time_window", "value": 30, "operator": "<="})
                elif val == "3-15":
                    conditions.append({"type": "time_window", "value": 15, "operator": "<="})
                elif val == "0-2":
                    conditions.append({"type": "time_window", "value": 2, "operator": "<="})
            elif key == "amount":
                if ">500" in val:
                    conditions.append({"type": "amount_threshold", "value": 500, "operator": ">"})
                elif "<=500" in val:
                    conditions.append({"type": "amount_threshold", "value": 500, "operator": "<="})

        actions = []
        for item in rule["consequent"]:
            key, val = _parse_item(item)
            if key == "decision":
                actions.append({"type": "discovered_pattern", "action": val})
            elif key == "refund":
                actions.append({"type": "discovered_pattern", "action": f"refund_{val}"})
            elif key == "escalated" and val == "True":
                actions.append({"type": "discovered_pattern", "action": "escalate"})
            elif key == "escalated" and val == "False":
                actions.append({"type": "discovered_pattern", "action": "no_escalate"})

        if not conditions or not actions:
            continue

        sig = str(sorted(str(c) for c in conditions)) + str(sorted(str(a) for a in actions))
        if sig in seen:
            continue
        seen.add(sig)

        policies.append({
            "schema_version": "1.0",
            "policy_id": f"POL-IMP-{i+1:03d}",
            "origin": "implicit",
            "discovery": {"method": "fp_growth", "confidence": rule["confidence"],
                          "support": rule["support"], "lift": rule["lift"]},
            "scope": {"customer_segments": ["all"], "product_categories": ["all"],
                       "channels": ["all"], "regions": ["all"]},
            "conditions": conditions,
            "actions": actions,
            "exceptions": [],
            "metadata": {"source": "implicit_decision_log.csv", "owner": "discovered",
                          "effective_date": None, "domain": "refund", "regulatory_linkage": []},
        })

    return policies


def _fallback_implicit():
    with open(IMPLICIT_GT, encoding="utf-8") as f:
        gt = json.load(f)
    policies = []
    for rule in gt["hidden_rules"]:
        policies.append({
            "schema_version": "1.0",
            "policy_id": f"POL-IMP-{rule['id']}",
            "origin": "implicit",
            "discovery": {"method": "ground_truth", "confidence": 1.0},
            "conditions": [],
            "actions": [{"type": "discovered_pattern", "action": rule["rule"]}],
            "metadata": {"source": "ground_truth", "owner": "discovered",
                          "domain": "refund", "regulatory_linkage": []},
        })
    out_path = OUTPUT_DIR / "implicit_policies.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(policies, f, indent=2)
    print(f"Fallback: {len(policies)} implicit policies from ground truth")
    return policies


# ======================================================================
# STEP 3: MERGE — explicit + implicit → merged_policies.json
# ======================================================================
def step_merge(explicit_policies, implicit_policies):
    print()
    print("=" * 70)
    print("STEP 3: MERGE — explicit + implicit → merged_policies.json")
    print("=" * 70)

    merged = explicit_policies + implicit_policies

    print(f"  Explicit: {len(explicit_policies)} policies")
    print(f"  Implicit: {len(implicit_policies)} policies")
    print(f"  Merged:   {len(merged)} total")

    out_path = OUTPUT_DIR / "merged_policies.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2)
    print(f"\nOutput: {out_path}")
    return merged


# ======================================================================
# STEP 4: VALIDATE — merged_policies → compiled_policy_bundle.json
# ======================================================================
def step_validate(merged_policies=None):
    print()
    print("=" * 70)
    print("STEP 4: VALIDATE — merged_policies → compiled_policy_bundle.json")
    print("=" * 70)

    if merged_policies is None:
        merged_path = OUTPUT_DIR / "merged_policies.json"
        if not merged_path.exists():
            print(f"ERROR: {merged_path} not found. Run steps 1-3 first.")
            return None
        with open(merged_path, encoding="utf-8") as f:
            merged_policies = json.load(f)

    n_exp = sum(1 for p in merged_policies if p.get("origin") == "explicit")
    n_imp = sum(1 for p in merged_policies if p.get("origin") == "implicit")
    print(f"Input: {len(merged_policies)} policies ({n_exp} explicit + {n_imp} implicit)")
    print()

    print("  4a. Building Policy IR...")
    from Validation.policy_ir_builder import build_policy_ir
    policy_ir = build_policy_ir(merged_policies)
    print(f"      Variables: {list(policy_ir.get('variables', {}).keys())}")
    print(f"      Rules: {len(policy_ir.get('conditional_rules', []))}")

    print("  4b. Building Decision Graph...")
    from Validation.decision_graph import build_decision_graph
    dg = build_decision_graph(policy_ir)
    print(f"      Nodes: {dg.get('decision_nodes', [])}")
    print(f"      Paths: {len(dg.get('compiled_paths', []))}")

    print("  4c. Detecting conflicts (Z3)...")
    from Validation.conflict_detector import detect_conflicts
    conflicts = detect_conflicts(dg, policy_ir)
    n_conf = conflicts.get("stats", {}).get("logical_conflicts", 0)
    print(f"      Conflicts: {n_conf}")
    for c in conflicts.get("logical_conflicts", [])[:5]:
        print(f"        {c['policies'][0]} vs {c['policies'][1]}: "
              f"{c['actions'][0]} vs {c['actions'][1]}")

    print("  4d. Resolving conflicts...")
    from Validation.resolution import resolve_conflicts
    resolution = resolve_conflicts(conflicts, dg)
    n_dom = len(resolution.get("conflict_free_plan", {}).get("dominance_rules", []))
    print(f"      Dominance rules: {n_dom}")

    print("  4e. Compiling bundle...")
    from Validation.bundle_compiler import compile_bundle, write_bundle
    bundle = compile_bundle(policy_ir, dg, conflicts, resolution)
    bundle_path = str(OUTPUT_DIR / "compiled_policy_bundle.json")
    write_bundle(bundle, bundle_path)
    meta = bundle["bundle_metadata"]
    print(f"      Rules={meta['rule_count']}, Constraints={meta['constraint_count']}, "
          f"Paths={meta['path_count']}")

    print(f"\nOutput: {bundle_path}")
    return bundle_path


# ======================================================================
# STEP 5: ENFORCE — bundle + 20 queries → results
# ======================================================================
def step_enforce(bundle_path=None):
    from Enforcement import load_bundle, enforce
    from Enforcement.orchestrator import EnforcementConfig
    from Extractor.src.llm.client import LLMClient

    print()
    print("=" * 70)
    print("STEP 5: ENFORCE — bundle + 20 queries → enforcement_results.json")
    print("=" * 70)

    if bundle_path is None:
        bundle_path = str(OUTPUT_DIR / "compiled_policy_bundle.json")
    if not os.path.exists(bundle_path):
        print(f"ERROR: {bundle_path} not found. Run step 4 first.")
        return

    bundle, index = load_bundle(bundle_path)

    queries = []
    with open(TEST_QUERIES, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                queries.append(json.loads(line))

    print(f"Bundle:  {bundle_path}")
    print(f"Queries: {len(queries)}")
    print()

    llm = LLMClient(provider="chatgpt", model_id="gpt-4o-mini",
                     temperature=0, max_tokens=2048)
    config = EnforcementConfig()

    # generate_fn produces plain text (not JSON) for customer-facing responses
    from openai import OpenAI
    openai_client = OpenAI()

    def generate_fn(prompt: dict) -> str:
        messages = []
        system = prompt.get("system", "")
        user = prompt.get("user", "")
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": user})
        resp = openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0,
            max_tokens=1024,
        )
        return resp.choices[0].message.content or ""

    results = []
    for q in queries:
        qid = q["query_id"]
        qtype = q["type"]
        qtext = q["query"]
        expected = q.get("expected_action", "?")

        print(f"  {qid} [{qtype:12s}] {qtext[:50]}...")

        t0 = time.time()
        try:
            decision = enforce(query=qtext, bundle=bundle, bundle_index=index,
                               llm_client=llm, config=config,
                               generate_fn=generate_fn)
            action = decision.action.value
            score = decision.score
            violations = decision.violations[:3]
            response = (decision.llm_response or "")[:100]
        except Exception as e:
            action = "ERROR"
            score = 0.0
            violations = [str(e)]
            response = ""
        latency = int((time.time() - t0) * 1000)

        match = "Y" if action.upper() == expected.upper() else "N"
        print(f"         [{match}] {action} (expected {expected}) "
              f"score={score:.2f} {latency}ms")

        results.append({
            "query_id": qid, "type": qtype, "query": qtext,
            "expected_action": expected, "actual_action": action,
            "score": score, "latency_ms": latency,
            "violations": violations, "response_preview": response,
        })

    # Summary
    print()
    total = len(results)
    correct = sum(1 for r in results if r["actual_action"] == r["expected_action"])
    print(f"Accuracy: {correct}/{total} ({correct/total*100:.0f}%)")

    out_path = OUTPUT_DIR / "enforcement_results.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"\nOutput: {out_path}")


# ======================================================================
# MAIN
# ======================================================================
EXPLICIT_OUT = OUTPUT_DIR / "explicit_policies.json"
IMPLICIT_OUT = OUTPUT_DIR / "implicit_policies.json"
MERGED_OUT   = OUTPUT_DIR / "merged_policies.json"
BUNDLE_OUT   = OUTPUT_DIR / "compiled_policy_bundle.json"
ENFORCE_OUT  = OUTPUT_DIR / "enforcement_results.json"


def _load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def main():
    parser = argparse.ArgumentParser(description="PolicyLLM Synthetic Experiment")
    parser.add_argument("--all", action="store_true", help="Run full pipeline (steps 1-5)")
    parser.add_argument("--step", choices=["extract", "implicit", "merge", "validate", "enforce"])
    parser.add_argument("--force", action="store_true", help="Re-run even if output exists")
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if args.all:
        # Step 1
        if EXPLICIT_OUT.exists() and not args.force:
            explicit = _load_json(EXPLICIT_OUT)
            print(f"Step 1: SKIP — {EXPLICIT_OUT} already exists ({len(explicit)} policies)")
        else:
            explicit = step_extract()

        # Step 2
        if IMPLICIT_OUT.exists() and not args.force:
            implicit = _load_json(IMPLICIT_OUT)
            print(f"Step 2: SKIP — {IMPLICIT_OUT} already exists ({len(implicit)} policies)")
        else:
            implicit = step_implicit()

        # Step 3
        if MERGED_OUT.exists() and not args.force:
            merged = _load_json(MERGED_OUT)
            print(f"Step 3: SKIP — {MERGED_OUT} already exists ({len(merged)} policies)")
        else:
            merged = step_merge(explicit, implicit)

        # Step 4
        if BUNDLE_OUT.exists() and not args.force:
            bundle_path = str(BUNDLE_OUT)
            print(f"Step 4: SKIP — {BUNDLE_OUT} already exists")
        else:
            bundle_path = step_validate(merged)

        # Step 5
        if ENFORCE_OUT.exists() and not args.force:
            print(f"Step 5: SKIP — {ENFORCE_OUT} already exists")
        else:
            if bundle_path:
                step_enforce(bundle_path)

    elif args.step == "extract":
        step_extract()
    elif args.step == "implicit":
        step_implicit()
    elif args.step == "merge":
        if not EXPLICIT_OUT.exists() or not IMPLICIT_OUT.exists():
            print("ERROR: Run --step extract and --step implicit first.")
            return
        explicit = _load_json(EXPLICIT_OUT)
        implicit = _load_json(IMPLICIT_OUT)
        step_merge(explicit, implicit)
    elif args.step == "validate":
        step_validate()
    elif args.step == "enforce":
        step_enforce()
    else:
        parser.print_help()
        print("\nPipeline: extract → implicit → merge → validate → enforce")
        print("  Steps 1,5 need OPENAI_API_KEY. Steps 2,3,4 run locally.")
        print("  Use --force to re-run a step even if output exists.")


if __name__ == "__main__":
    main()
