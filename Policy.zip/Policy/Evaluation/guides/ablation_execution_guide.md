# Ablation 실행 가이드 — Person 3 전달용

> **목적**: PolicyLLM의 각 모듈이 실제로 기여하는지 증명.
> "그냥 프롬프팅 아니야?" 비판을 실험적으로 반박하는 핵심 데이터.
> (슬라이드 39 방어용)

---

## A. Module Ablation — 모듈 하나씩 끄기

### 원리

PolicyLLM full 시스템에서 모듈을 하나씩 제거하고 compliance rate 변화를 측정.
**떨어지면 그 모듈이 기여한다는 증거.**

### 돌려야 할 7개 variant

| Variant ID | 이름 | 끄는 모듈 | 파이프라인 상태 |
|------------|------|----------|----------------|
| `full` | PolicyLLM (full) | 없음 (모두 ON) | Pre ✅ During ✅ Post ✅ Conflict ✅ Formal ✅ |
| `no_post_gen` | − Post-Gen | `post_gen` | Pre ✅ During ✅ Post ❌ Conflict ✅ Formal ✅ |
| `no_during_gen` | − During-Gen | `during_gen` | Pre ✅ During ❌ Post ✅ Conflict ✅ Formal ✅ |
| `no_conflict` | − Conflict Detection | `conflict_detection` | Pre ✅ During ✅ Post ✅ Conflict ❌ Formal ✅ |
| `no_metadata` | − Metadata | `metadata` | Pre ✅ During ✅ Post ✅ Conflict ✅ Formal ✅ (우선순위 해석 없이) |
| `no_formalization` | − Formalization | `formalization` | Pre ✅ During ✅ Post ✅ Conflict ❌ Formal ❌ |
| `pre_gen_only` | Pre-Gen only (≈ RAG) | `during_gen`, `post_gen`, `conflict_detection`, `formalization` | Pre ✅ During ❌ Post ❌ Conflict ❌ Formal ❌ |

### 각 variant별 구체적 동작

**`full`** — 그대로 전체 파이프라인

**`no_post_gen`** — Post-Generation verification 스킵
```python
# 원래 흐름: generate → post_verify → return
# 변경: generate → return (검증 없이 바로 반환)
config.enforcement.post_gen = False
```

**`no_during_gen`** — During-Generation CoT scaffold 스킵
```python
# 원래 흐름: system_prompt에 CoT instructions + policy constraints 삽입
# 변경: system_prompt에서 CoT 관련 부분 제거, 정책만 남김
config.enforcement.during_gen = False
```

**`no_conflict`** — Conflict Detection 결과 무시
```python
# 원래 흐름: 충돌 정책 발견 → 우선순위에 따라 하나 선택
# 변경: 모든 정책을 충돌 체크 없이 그대로 적용
config.conflict_detection = False
```

**`no_metadata`** — 메타데이터 기반 우선순위 해석 제거
```python
# 원래 흐름: effective_date, regulatory_linkage 등으로 우선순위 결정
# 변경: 정책 간 우선순위 구분 없이 동등하게 처리
config.metadata_priority = False
```

**`no_formalization`** — Formalization (logic rules + decision graph) 제거
```python
# 원래 흐름: Stage 2 JSON의 logic_rules, constraints, decision_graph 활용
# 변경: Stage 1 JSON (raw text)만으로 처리 (= LLM이 텍스트만 보고 판단)
config.formalization = False
config.conflict_detection = False  # formalization 없으면 SMT도 불가
```

**`pre_gen_only`** — RAG만 남기고 나머지 다 끔
```python
# = system_prompt에 검색된 정책 텍스트만 넣고, CoT/검증/충돌감지 전부 OFF
# 이게 "그냥 프롬프팅"에 가장 가까운 baseline
config.enforcement.during_gen = False
config.enforcement.post_gen = False
config.conflict_detection = False
config.formalization = False
```

### 입력

**Task 3과 동일한 쿼리셋** 사용: `policyllm-eval/data/test_queries.jsonl` (2,000개)

### 출력 포맷

Task 3과 **완전히 동일**:

```jsonl
{"query_id": "Q-JETBLUE-0001", "response_text": "...", "latency_ms": 1042, "blocked": false}
{"query_id": "Q-JETBLUE-0002", "response_text": "...", "latency_ms": 983, "blocked": false}
```

### 저장 경로 (⚠️ 반드시 이 경로)

```
policyllm-eval/results/ablation/
├── full/
│   └── responses.jsonl          ← 2,000줄
├── no_post_gen/
│   └── responses.jsonl
├── no_during_gen/
│   └── responses.jsonl
├── no_conflict/
│   └── responses.jsonl
├── no_metadata/
│   └── responses.jsonl
├── no_formalization/
│   └── responses.jsonl
└── pre_gen_only/
    └── responses.jsonl
```

---

## B. Layer Ablation — 레이어 조합 실험

### 원리

PolicyLLM은 defense-in-depth (슬라이드 27): Fine-tuning + System Prompt + RAG + Guardrail.
각 레이어 단독 vs 전체 조합을 비교하여 **다층 방어가 필요함**을 증명.

### 돌려야 할 5개 variant

| Variant ID | 이름 | 활성 레이어 |
|------------|------|------------|
| `layer_fine_tuning_only` | Fine-tuning only | 파인튜닝된 모델만, 추가 prompt/RAG/guardrail 없음 |
| `layer_system_prompt_only` | System prompt only | 정책 텍스트를 system prompt에 넣기만 |
| `layer_rag_only` | RAG only | 관련 정책 검색 → context injection만 |
| `layer_guardrail_only` | Guardrail only | 입출력 필터링만 (NeMo/custom rules) |
| `layer_all_layers` | All layers combined | 전부 활성화 (= PolicyLLM full과 동일) |

### 각 variant별 구체적 동작

**`layer_fine_tuning_only`**
```python
# 정책에 맞게 fine-tuning된 모델 사용
# system prompt: 일반 customer service 역할만
# RAG: OFF, Guardrail: OFF
model = "ft:gpt-4o:policyllm:..."  # fine-tuned model
system_prompt = "You are a helpful customer service agent."
```

**`layer_system_prompt_only`**
```python
# base model (fine-tuning 없음)
# system prompt에 관련 정책 텍스트 전부 concat
# RAG: OFF (정책이 이미 system prompt에 있으니까)
# Guardrail: OFF
model = "gpt-4o"  # base model
system_prompt = f"Follow these policies:\n{all_policies_for_company}"
```

**`layer_rag_only`**
```python
# base model
# system prompt: 일반 역할만
# RAG: query 기반 top-5 정책 검색 → user message에 context로 추가
# Guardrail: OFF
```

**`layer_guardrail_only`**
```python
# base model
# system prompt: 일반 역할만
# RAG: OFF
# Guardrail: input 필터 (위험 쿼리 차단) + output 필터 (정책 위반 응답 차단)
# 정책 텍스트는 guardrail rule로만 인코딩
```

**`layer_all_layers`**
```python
# = full PolicyLLM. full variant와 결과 동일해야 함 (sanity check)
```

### 저장 경로

```
policyllm-eval/results/ablation/
├── layer_fine_tuning_only/
│   └── responses.jsonl
├── layer_system_prompt_only/
│   └── responses.jsonl
├── layer_rag_only/
│   └── responses.jsonl
├── layer_guardrail_only/
│   └── responses.jsonl
└── layer_all_layers/
    └── responses.jsonl
```

---

## 실행 순서 추천

```
1. full                    ← 먼저 (기준점)
2. pre_gen_only            ← "그냥 RAG"와의 차이 확인
3. no_post_gen             ← Post-Gen 기여도
4. no_during_gen           ← During-Gen 기여도
5. no_conflict             ← Conflict Detection 기여도
6. no_formalization        ← Formalization 기여도
7. no_metadata             ← Metadata 기여도
8. layer_* (5개)           ← Layer 조합 실험
```

**최소한 1-4번은 반드시 해야** 논문 Table 8 (ablation table)을 채울 수 있음.

---

## 기대 결과 (논문에서 보여주고 싶은 것)

### Module Ablation Table (Table 8)

| Variant | Compliance Rate | Δ | FP Rate | Latency |
|---------|:-:|:-:|:-:|:-:|
| PolicyLLM (full) | **94.2%** | — | 2.1% | 1,200ms |
| − Post-Gen | ~90% | −4pp | ↑ | ↓ |
| − During-Gen | ~87% | −7pp | ↑ | ↓↓ |
| − Conflict Detection | ~91% | −3pp | ↑ | ≈ |
| − Formalization | ~88% | −6pp | ↑↑ | ↓ |
| Pre-Gen only (≈ RAG) | ~82% | −12pp | ↑↑↑ | ↓↓↓ |

**핵심 포인트**: Pre-Gen only (≈ RAG) → full 사이에 **+12pp** 차이가 나면
"프롬프팅만으로 충분하다"는 비판을 정량적으로 반박할 수 있음.

### Layer Ablation Table

| Layers | Compliance Rate |
|--------|:-:|
| Fine-tuning only | ~78% |
| System prompt only | ~80% |
| RAG only | ~82% |
| Guardrail only | ~75% |
| **All combined** | **~94%** |

**핵심 포인트**: 어떤 단일 레이어도 94%에 못 미침 → defense-in-depth 필요성 입증.

---

## 체크리스트

- [ ] Module ablation: 7개 variant × `responses.jsonl` = 7개 파일
- [ ] Layer ablation: 5개 variant × `responses.jsonl` = 5개 파일
- [ ] 총 12개 파일, 각각 2,000줄
- [ ] 모든 파일에 `query_id`, `response_text`, `latency_ms`, `blocked` 포함
- [ ] `full`과 `layer_all_layers` 결과가 거의 동일한지 확인 (sanity check)

---

## 완료되면

Person 4한테 알려주세요. 바로 이걸 돌립니다:

```bash
python scripts/08_ablation_study.py --type all
```

→ Table 8 자동 생성
