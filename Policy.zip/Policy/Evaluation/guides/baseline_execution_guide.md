# Baseline 실행 가이드 — Person 1, 2, 3 전달용

> **목적**: 각 Person이 자기 모듈 + baseline을 정해진 설정으로 돌리고, 정해진 경로에 저장해주면
> Person 4 (Evaluation Lead)가 평가 스크립트로 자동 비교합니다.

## 공통 설정

```
LLM backbone: gpt-4o
Temperature: 0
Seed: 42
반복 횟수: 3회 (run_1, run_2, run_3)
```

---

## Person 1: Task 1 — Policy Extraction

### 너가 돌려야 할 것: 4개 method × 6개 회사 = 24회 (× 3 반복 = 72회)

| Method ID | 이름 | 누가 구현 | 설명 |
|-----------|------|----------|------|
| `rule_based` | Rule-based (regex) | **Person 1** | 정규식 기반 추출 |
| `gpt4o_zeroshot` | GPT-4o zero-shot | **Person 1** | "Extract policies from this document" 한 번 |
| `gpt4o_json_schema` | GPT-4o + JSON schema | **Person 1** | Stage 1 JSON 스키마를 prompt에 포함 |
| `ours_multipass` | Ours (multi-pass) | **Person 1** | 5-pass pipeline (segmentation → classification → component → entity → validation) |

### 회사 목록

`jetblue`, `delta`, `chase`, `wells_fargo`, `amazon`, `target`

### 입력

각 회사의 policy 문서 (니가 수집한 것)

### 출력 포맷

**각 method × 각 회사마다** Stage 1 JSON 리스트를 저장:

```json
[
  {
    "schema_version": "1.0",
    "processing_status": { "extraction": "complete", ... },
    "policy_id": "POL-REFUND-001",
    "origin": "explicit",
    "scope": { "customer_segments": [...], ... },
    "conditions": [ { "type": "time_window", "value": 30, "unit": "days", "operator": "<=", "target": "general", "source_text": "..." } ],
    "actions": [ { "type": "required", "action": "full_refund", "requires": [...], "source_text": "..." } ],
    "exceptions": [...],
    "metadata": { "source": "...", "domain": "refund", ... }
  },
  ...
]
```

### 저장 경로 (⚠️ 반드시 이 경로)

```
policyllm-eval/results/task1_extraction/
├── rule_based/
│   ├── jetblue/
│   │   └── policies.json          ← [policy, policy, ...]
│   ├── delta/
│   │   └── policies.json
│   ├── chase/
│   │   └── policies.json
│   ├── wells_fargo/
│   │   └── policies.json
│   ├── amazon/
│   │   └── policies.json
│   └── target/
│       └── policies.json
├── gpt4o_zeroshot/
│   ├── jetblue/
│   │   └── policies.json
│   └── ...
├── gpt4o_json_schema/
│   ├── jetblue/
│   │   └── policies.json
│   └── ...
└── ours_multipass/
    ├── jetblue/
    │   └── policies.json
    └── ...
```

### Baseline 구현 가이드

**1) rule_based** — 직접 regex 패턴 작성
```python
# 최소한 이런 패턴들:
import re
patterns = {
    "time_window": r"within\s+(\d+)\s+(days?|hours?|months?)",
    "amount_threshold": r"(over|above|below|under|more than|less than)\s*\$?([\d,]+)",
    "boolean_flag": r"(must|required|need)\s+(have|present|provide)\s+(receipt|ID|proof)",
}
# 매치된 것을 Stage 1 JSON으로 변환
```

**2) gpt4o_zeroshot** — prompt 1회
```
System: You are a policy extraction assistant.
User: Extract all policies from this document. For each policy, identify:
- scope, conditions, actions, exceptions
Return as JSON array.

{document_text}
```

**3) gpt4o_json_schema** — prompt에 스키마 포함
```
System: You are a policy extraction assistant. Output must follow this exact JSON schema:
{Stage 1 JSON schema 전문}

User: Extract all policies from this document.
{document_text}
```

**4) ours_multipass** — 니 파이프라인 그대로 돌리면 됨

### 체크리스트

- [ ] 4개 method × 6개 회사 = 24개 `policies.json` 파일 생성됨
- [ ] 모든 JSON이 Stage 1 스키마 준수 (`schema_version`, `conditions`, `actions` 등)
- [ ] 각 condition에 `source_text` 포함 (zero-shot, rule_based는 빈 문자열 OK)

---

## Person 2: Task 2 — Conflict Detection

### 너가 돌려야 할 것: 5개 method × 6개 회사 = 30회 (× 3 반복 = 90회)

| Method ID | 이름 | 설명 |
|-----------|------|------|
| `keyword_overlap` | Keyword overlap | 두 policy 텍스트에서 겹치는 키워드 ≥3개면 conflict |
| `semantic_similarity` | Semantic similarity | Sentence-BERT cosine sim ≥ 0.75면 conflict |
| `smt_only` | SMT only (Z3) | Stage 2 logic rules → Z3 satisfiability check만 |
| `llm_zeroshot` | LLM zero-shot | GPT-4o에게 "이 두 정책 충돌해?" 한 번 물어봄 |
| `ours_hybrid` | Ours (hybrid) | SMT + Semantic + LLM 3단계 파이프라인 |

### 입력

Person 1의 `ours_multipass` 추출 결과 (Stage 1 JSON)에서 **같은 회사** 내 모든 policy 쌍

### 출력 포맷

```json
[
  {
    "policy_a": "POL-REFUND-001",
    "policy_b": "POL-REFUND-003",
    "conflict_detected": true,
    "conflict_type": "logical",
    "confidence": 0.92,
    "explanation": "15-day electronics window contradicts 30-day general window when product is electronics"
  },
  ...
]
```

### 저장 경로

```
policyllm-eval/results/task2_conflict/
├── keyword_overlap/
│   ├── jetblue/
│   │   └── conflicts.json
│   ├── delta/
│   │   └── conflicts.json
│   └── ...
├── semantic_similarity/
│   └── ...
├── smt_only/
│   └── ...
├── llm_zeroshot/
│   └── ...
└── ours_hybrid/
    └── ...
```

### Baseline 구현 가이드

**1) keyword_overlap**
```python
from collections import Counter

def keyword_overlap(policy_a_text, policy_b_text, min_overlap=3):
    words_a = set(policy_a_text.lower().split())
    words_b = set(policy_b_text.lower().split())
    # stopwords 제거
    overlap = words_a & words_b - STOPWORDS
    return len(overlap) >= min_overlap
```

**2) semantic_similarity**
```python
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")
emb_a = model.encode(policy_a_text)
emb_b = model.encode(policy_b_text)
sim = cosine_similarity(emb_a, emb_b)
conflict = sim >= 0.75  # 유사하면 충돌 가능
```

**3) smt_only** — Stage 2 logic rules를 Z3에 넣어서 UNSAT이면 conflict

**4) llm_zeroshot**
```
System: You are a policy conflict detector.
User: Do these two policies conflict? Answer with JSON: {"conflict": true/false, "type": "logical/semantic/none", "explanation": "..."}

Policy A: {policy_a_text}
Policy B: {policy_b_text}
```

**5) ours_hybrid** — 니 파이프라인 그대로

### 체크리스트

- [ ] 5개 method × 6개 회사 = 30개 `conflicts.json` 파일
- [ ] 각 entry에 `policy_a`, `policy_b`, `conflict_detected` 필수
- [ ] policy_a, policy_b는 Person 1 output의 `policy_id`와 정확히 일치

---

## Person 3: Task 3 — End-to-End Compliance

### 너가 돌려야 할 것: 7개 method × 2,000 queries = 14,000 responses (× 3 반복 = 42,000)

| Method ID | 이름 | 설명 |
|-----------|------|------|
| `vanilla_gpt4o` | Vanilla GPT-4o | 정책 없이 일반 고객 응대 |
| `system_prompt_only` | System Prompt Only | 모든 정책을 system prompt에 concat |
| `rag_only` | RAG Only | query와 관련 정책 top-5 검색 후 context injection |
| `nemo_guardrails` | NeMo Guardrails | Colang rules로 input/output 필터링 |
| `llama_guard_3` | Llama Guard 3 | Meta safety model로 필터링 |
| `wildguard_7b` | WildGuard-7B | AllenAI safety model로 필터링 |
| `policyllm` | PolicyLLM (full) | 전체 파이프라인 (Pre+During+Post) |

### 입력

`policyllm-eval/data/test_queries.jsonl` — Person 4가 제공 (2,000 queries)

```json
{"query_id": "Q-JETBLUE-0001", "company": "jetblue", "query_text": "I need to cancel my flight...", "query_type": "normal", ...}
```

### 출력 포맷

**각 method별** JSONL 파일:

```jsonl
{"query_id": "Q-JETBLUE-0001", "response_text": "I understand you'd like to cancel...", "latency_ms": 1042, "blocked": false}
{"query_id": "Q-JETBLUE-0002", "response_text": "Based on our refund policy...", "latency_ms": 983, "blocked": false}
{"query_id": "Q-DELTA-0001", "response_text": "I'm sorry, I cannot process...", "latency_ms": 2103, "blocked": true}
```

필수 필드:
- `query_id`: test_queries.jsonl의 query_id와 정확히 일치
- `response_text`: 시스템이 생성한 응답 전문
- `latency_ms`: 요청~응답 wall clock time (밀리초)
- `blocked`: 시스템이 응답을 거부/차단했으면 true

### 저장 경로

```
policyllm-eval/results/task3_e2e/
├── vanilla_gpt4o/
│   └── responses.jsonl          ← 2,000줄
├── system_prompt_only/
│   └── responses.jsonl
├── rag_only/
│   └── responses.jsonl
├── nemo_guardrails/
│   └── responses.jsonl
├── llama_guard_3/
│   └── responses.jsonl
├── wildguard_7b/
│   └── responses.jsonl
└── policyllm/
    └── responses.jsonl
```

### Baseline 구현 가이드

**1) vanilla_gpt4o**
```python
response = client.chat.completions.create(
    model="gpt-4o",
    temperature=0,
    messages=[
        {"role": "system", "content": "You are a helpful customer service agent."},
        {"role": "user", "content": query_text}
    ]
)
```

**2) system_prompt_only**
```python
# 해당 회사의 모든 정책 텍스트를 concat
all_policies = load_company_policies(company)
system_prompt = f"You are a customer service agent. Follow these policies strictly:\n\n{all_policies}"

response = client.chat.completions.create(
    model="gpt-4o",
    temperature=0,
    messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": query_text}
    ]
)
```

**3) rag_only**
```python
# query 임베딩 → 가장 관련있는 정책 top-5 검색
relevant_policies = retrieve_top_k(query_text, company, k=5)
context = "\n\n".join(relevant_policies)

response = client.chat.completions.create(
    model="gpt-4o",
    temperature=0,
    messages=[
        {"role": "system", "content": f"Answer based on these policies:\n{context}"},
        {"role": "user", "content": query_text}
    ]
)
```

**4-6) nemo / llama_guard / wildguard** — 각 라이브러리 docs 참고해서 gpt-4o 앞뒤에 필터 적용

**7) policyllm** — 전체 파이프라인 (Pre-Gen RAG → During-Gen CoT → Post-Gen verification)

### Latency 측정 코드

```python
import time

start = time.perf_counter()
response = run_method(query)
end = time.perf_counter()
latency_ms = int((end - start) * 1000)
```

### 체크리스트

- [ ] 7개 method × 1개 `responses.jsonl` = 7개 파일
- [ ] 각 파일에 정확히 2,000줄 (빠진 query_id 없이)
- [ ] 모든 줄에 `query_id`, `response_text`, `latency_ms`, `blocked` 포함
- [ ] warmup: 첫 50개 query는 latency 측정에서 제외 (본인 코드에서 처리)

---

## 반복 실험 (3회)

정확한 통계를 위해 **3회 반복**:
- seed=42, seed=43, seed=44 (또는 run_1, run_2, run_3)
- 결과 파일명: `responses_run1.jsonl`, `responses_run2.jsonl`, `responses_run3.jsonl`
- 평가 스크립트가 3회 평균 ± 표준편차 자동 계산

3회 반복이 어렵다면 **최소 1회**라도 먼저 제출하고, 나중에 추가해도 됩니다.

---

## 질문 있으면

Person 4 (Evaluation Lead)에게 연락. 평가 스크립트는 이미 다 준비됨:
- Task 1: `python scripts/05_task1_extraction_eval.py`
- Task 2: `python scripts/06_task2_conflict_eval.py`
- Task 3: `python scripts/07_task3_e2e_eval.py`

**저장 경로만 정확히 맞춰주면 바로 돌릴 수 있습니다.**
