# Annotation Protocol

## Overview

Two annotation tasks support the PolicyLLM evaluation:
1. **Extraction Annotation** (Task 1 ground truth): Label policy components in documents
2. **Conflict Annotation** (Task 2 ground truth): Label whether policy pairs conflict

Target: 3 annotators (2 legal professionals + 1 policy analyst), Cohen's κ ≥ 0.74

---

## Task A: Extraction Annotation

### Objective
For each policy document, annotate the structured components that should be extracted.

### Instructions for Annotators

For each document section that contains a policy:

1. **scope**: Who/what does this policy apply to?
   - Customer segments (all, VIP, new, etc.)
   - Product categories (all, electronics, perishables, etc.)
   - Channels (online, in-store, phone)

2. **conditions**: What must be true for the policy to apply?
   - Time windows ("within 30 days")
   - Amount thresholds ("orders over $50")
   - Customer requirements ("must be authenticated")
   - Mark each condition with: type, value, unit, operator

3. **actions**: What happens when conditions are met?
   - Required actions ("issue full refund")
   - Prohibited actions ("never disclose PII")
   - Fallback actions ("store credit if no receipt")

4. **exceptions**: What overrides the general rule?
   - Category exceptions ("electronics: 15 days instead of 30")
   - Role exceptions ("VIP members exempt from fee")
   - Link each exception to which condition/action it overrides

### Output Format (per document)

```json
{
  "doc_id": "return_policy_v3.2",
  "annotator_id": 1,
  "policies": [
    {
      "policy_id": "manual-001",
      "text_span": "Customers may return items within 30 days...",
      "page": 4,
      "section": "4.1",
      "components": {
        "scope": {
          "text": "All customers, all product categories",
          "customer_segments": ["all"],
          "product_categories": ["all"]
        },
        "conditions": [
          {
            "text": "within 30 days of purchase",
            "type": "time_window",
            "value": 30,
            "unit": "days",
            "operator": "<="
          }
        ],
        "actions": [
          {
            "text": "full refund",
            "type": "required",
            "action": "full_refund"
          }
        ],
        "exceptions": [
          {
            "text": "Electronics must be returned within 15 days",
            "overrides": "conditions[0]",
            "new_value": 15
          }
        ]
      }
    }
  ]
}
```

### Annotation Rules
- One policy per identifiable rule (a paragraph may contain multiple policies)
- Always include the `text_span` (exact original text)
- If unsure whether something is a condition or exception, mark it as condition
- If a section is informational only (no actionable rule), skip it

---

## Task B: Conflict Annotation

### Objective
For each pair of policies within a company, determine whether they conflict.

### Instructions for Annotators

Given two policies (already extracted into components):

1. **Read both policies carefully**
2. **Ask**: Is there any scenario where following both policies simultaneously would be impossible or contradictory?
3. **Label**:
   - `1` = Conflict exists
   - `0` = No conflict

4. **If conflict exists, classify type**:
   - `logical`: Following both is logically impossible (e.g., "free shipping" vs "$5.99 fee" for same order)
   - `semantic`: No logical contradiction, but intent-level tension (e.g., "suggest alternatives" vs "never mention competitors")

5. **Describe the conflict** in one sentence

### Output Format (per pair)

```json
{
  "pair_id": "CF-CHASE-001",
  "company": "chase",
  "policy_a": "POL-ACCOUNT-001",
  "policy_b": "POL-FEES-003",
  "policy_a_text": "...",
  "policy_b_text": "...",
  "annotator_id": 1,
  "has_conflict": 1,
  "conflict_type": "logical",
  "description": "Account fee waiver for Gold members conflicts with universal monthly maintenance fee",
  "confidence": "high"
}
```

### Annotation Rules
- Only annotate pairs within the same company
- Consider the most natural reading (don't create implausible scenarios)
- "Confidence" is self-assessed: high / medium / low
- Pairs with different scopes (e.g., one applies only to VIP, other to all) may still conflict if scopes overlap

---

## Agreement Measurement

After all 3 annotators complete both tasks:

1. Run `python scripts/04_annotation_agreement.py`
2. Report Cohen's κ (pairwise) and Fleiss' κ (all three)
3. **Disagreement resolution**: majority vote (2/3). If all three disagree, discuss and re-label.

Target: κ ≥ 0.74 for extraction, κ ≥ 0.74 for conflicts (matching paper claims)

---

## Pair Selection for Conflict Annotation

Not all pairs need annotation (combinatorial explosion). Selection strategy:

1. **All pairs with cosine similarity ≥ 0.6** (Sentence-BERT on policy text)
2. **Random sample of 20% of remaining pairs** (to estimate false negative rate)
3. **All pairs flagged by any detection method** (ensures evaluation covers system outputs)

This produces a manageable annotation set while covering the important cases.
