"""
runner.py — Full experiment orchestrator.

Connects all 4 groups' code into one executable flow:
  Extractor (Group 1) → Validation (Group 2) → Enforcement (Group 3) → Evaluation (Group 4)

Usage:
    # From PolicyLLM root:
    python -m Evaluation.runner --task all --provider chatgpt --model gpt-4o
    python -m Evaluation.runner --task task3 --provider chatgpt --model gpt-4o-mini
    python -m Evaluation.runner --task ablation --provider chatgpt --model gpt-4o-mini
"""
import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# Ensure project root is importable
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from Extractor.src.config import load_config as load_extractor_config
from Extractor.src.pipeline import run_pipeline as run_extraction
from Extractor.src.llm.client import LLMClient
from Validation.bundle_compiler import compile_from_policies, write_bundle
from Validation.conflict_detector import detect_conflicts
from Validation.policy_ir_builder import build_policy_ir
from Validation.decision_graph import build_decision_graph
from Enforcement import load_bundle, enforce
from Enforcement.orchestrator import EnforcementConfig

logger = logging.getLogger("Evaluation")

EVAL_ROOT = Path(__file__).resolve().parent
RESULTS_DIR = EVAL_ROOT / "results"
DATA_DIR = EVAL_ROOT / "data"


# ==========================================================================
# Task 1: Extraction Evaluation
# ==========================================================================
def run_task1(
    docs_dir: str,
    provider: str,
    model: str,
    companies: List[str] = None,
) -> Dict[str, Any]:
    """
    Run 4 extraction methods on company policy documents.
    Directly calls Extractor pipeline.

    Args:
        docs_dir: Path to dir with company subdirs, each containing policy docs
        provider: LLM provider (chatgpt, ollama, etc.)
        model: Model ID
        companies: List of company names (subdirs in docs_dir)
    """
    if companies is None:
        companies = ["jetblue", "delta", "chase", "wells_fargo", "amazon", "target"]

    results = {}

    for company in companies:
        company_dir = Path(docs_dir) / company
        if not company_dir.exists():
            logger.warning("Skipping %s: directory not found", company)
            continue

        doc_files = list(company_dir.glob("*"))
        if not doc_files:
            logger.warning("Skipping %s: no documents found", company)
            continue

        logger.info("=== Task 1: %s (%d docs) ===", company, len(doc_files))

        for doc_path in doc_files:
            # --- Method 1: rule_based ---
            # (separate script; skip here, Person 1 runs manually)

            # --- Method 2: gpt4o_zeroshot ---
            out_dir = RESULTS_DIR / "task1_extraction" / "gpt4o_zeroshot" / company
            out_dir.mkdir(parents=True, exist_ok=True)
            llm = LLMClient(provider=provider, model_id=model, temperature=0, max_tokens=4096)
            zeroshot_policies = _run_zeroshot_extraction(doc_path, llm)
            with open(out_dir / "policies.json", "w") as f:
                json.dump(zeroshot_policies, f, indent=2)

            # --- Method 3: gpt4o_json_schema ---
            out_dir = RESULTS_DIR / "task1_extraction" / "gpt4o_json_schema" / company
            out_dir.mkdir(parents=True, exist_ok=True)
            schema_policies = _run_schema_extraction(doc_path, llm)
            with open(out_dir / "policies.json", "w") as f:
                json.dump(schema_policies, f, indent=2)

            # --- Method 4: ours_multipass ---
            out_dir = RESULTS_DIR / "task1_extraction" / "ours_multipass" / company
            out_dir.mkdir(parents=True, exist_ok=True)
            config = load_extractor_config(
                str(PROJECT_ROOT / "Extractor" / "configs" / "config.chatgpt.yaml")
            )
            # Override with provided model
            config.llm.provider = provider
            config.llm.model_id = model
            run_extraction(
                input_path=str(doc_path),
                output_dir=str(out_dir),
                tenant_id=company,
                batch_id="eval",
                config=config,
            )

        results[company] = {"status": "complete", "methods": 3}

    return results


def _run_zeroshot_extraction(doc_path: Path, llm: LLMClient) -> List[Dict]:
    """GPT-4o zero-shot baseline: single prompt, no schema."""
    with open(doc_path) as f:
        text = f.read()

    prompt = f"""Extract all policies from this document. For each policy, identify:
- scope (who/what it applies to)
- conditions (requirements, thresholds, time windows)
- actions (what must/must not happen)
- exceptions (overrides, special cases)

Return as a JSON array of policy objects.

Document:
{text}"""

    result = llm.invoke_json(prompt)
    if isinstance(result, list):
        return result
    return [result] if isinstance(result, dict) else []


def _run_schema_extraction(doc_path: Path, llm: LLMClient) -> List[Dict]:
    """GPT-4o + JSON schema baseline: prompt includes Stage 1 schema."""
    with open(doc_path) as f:
        text = f.read()

    schema_desc = """Output must follow this exact JSON schema for EACH policy:
{
  "schema_version": "1.0",
  "processing_status": {"extraction": "complete", "formalization": "pending", "conflict_detection": "pending", "layer_assignment": "pending"},
  "policy_id": "POL-DOMAIN-001",
  "origin": "explicit",
  "scope": {"customer_segments": [], "product_categories": [], "channels": [], "regions": []},
  "conditions": [{"type": "time_window|amount_threshold|customer_tier|product_category|geographic|boolean_flag|role_requirement", "value": ..., "unit": "...", "operator": "<=|>=|==|!=|<|>", "target": "...", "source_text": "..."}],
  "actions": [{"type": "required|prohibited|fallback|conditional", "action": "...", "requires": [], "source_text": "..."}],
  "exceptions": [{"description": "...", "source_text": "..."}],
  "metadata": {"source": "...", "owner": "...", "effective_date": null, "domain": "...", "regulatory_linkage": []}
}"""

    prompt = f"""{schema_desc}

Extract all policies from this document. Return a JSON array.

Document:
{text}"""

    result = llm.invoke_json(prompt)
    if isinstance(result, list):
        return result
    return [result] if isinstance(result, dict) else []


# ==========================================================================
# Task 2: Conflict Detection Evaluation
# ==========================================================================
def run_task2(
    provider: str,
    model: str,
    companies: List[str] = None,
) -> Dict[str, Any]:
    """
    Run 5 conflict detection methods.
    Directly calls Validation module for SMT-based methods.
    """
    if companies is None:
        companies = ["jetblue", "delta", "chase", "wells_fargo", "amazon", "target"]

    results = {}

    for company in companies:
        # Load ours_multipass extraction output
        policies_path = RESULTS_DIR / "task1_extraction" / "ours_multipass" / company / "policies.json"
        if not policies_path.exists():
            # Try JSONL format
            jsonl_files = list((RESULTS_DIR / "task1_extraction" / "ours_multipass" / company).glob("*.jsonl"))
            if jsonl_files:
                policies = []
                with open(jsonl_files[0]) as f:
                    for line in f:
                        if line.strip():
                            policies.append(json.loads(line))
            else:
                logger.warning("Skipping %s: no extraction output found", company)
                continue
        else:
            with open(policies_path) as f:
                policies = json.load(f)

        if len(policies) < 2:
            logger.warning("Skipping %s: need at least 2 policies for conflict detection", company)
            continue

        logger.info("=== Task 2: %s (%d policies) ===", company, len(policies))

        # --- Method 1: keyword_overlap ---
        out_dir = RESULTS_DIR / "task2_conflict" / "keyword_overlap" / company
        out_dir.mkdir(parents=True, exist_ok=True)
        kw_conflicts = _keyword_overlap_baseline(policies)
        with open(out_dir / "conflicts.json", "w") as f:
            json.dump(kw_conflicts, f, indent=2)

        # --- Method 2: semantic_similarity ---
        out_dir = RESULTS_DIR / "task2_conflict" / "semantic_similarity" / company
        out_dir.mkdir(parents=True, exist_ok=True)
        sem_conflicts = _semantic_similarity_baseline(policies)
        with open(out_dir / "conflicts.json", "w") as f:
            json.dump(sem_conflicts, f, indent=2)

        # --- Method 3: smt_only (uses Validation module directly) ---
        out_dir = RESULTS_DIR / "task2_conflict" / "smt_only" / company
        out_dir.mkdir(parents=True, exist_ok=True)
        policy_ir = build_policy_ir(policies)
        decision_graph = build_decision_graph(policy_ir)
        smt_report = detect_conflicts(decision_graph, policy_ir)
        smt_conflicts = [
            {
                "policy_a": c["policies"][0],
                "policy_b": c["policies"][1],
                "conflict_detected": True,
                "conflict_type": c["type"],
                "confidence": 1.0,
                "explanation": f"Z3 witness: {c.get('witness', {})}",
            }
            for c in smt_report.get("logical_conflicts", [])
        ]
        with open(out_dir / "conflicts.json", "w") as f:
            json.dump(smt_conflicts, f, indent=2)

        # --- Method 4: llm_zeroshot ---
        out_dir = RESULTS_DIR / "task2_conflict" / "llm_zeroshot" / company
        out_dir.mkdir(parents=True, exist_ok=True)
        llm = LLMClient(provider=provider, model_id=model, temperature=0, max_tokens=2048)
        llm_conflicts = _llm_zeroshot_conflict(policies, llm)
        with open(out_dir / "conflicts.json", "w") as f:
            json.dump(llm_conflicts, f, indent=2)

        # --- Method 5: ours_hybrid (SMT + semantic + LLM) ---
        out_dir = RESULTS_DIR / "task2_conflict" / "ours_hybrid" / company
        out_dir.mkdir(parents=True, exist_ok=True)
        # Full Validation pipeline
        bundle_data = compile_from_policies(policies)
        # Extract conflicts from bundle compilation
        hybrid_conflicts = smt_conflicts.copy()  # Start with SMT results
        # TODO: add semantic + LLM layers from Person 2's full pipeline
        with open(out_dir / "conflicts.json", "w") as f:
            json.dump(hybrid_conflicts, f, indent=2)

        results[company] = {
            "status": "complete",
            "n_policies": len(policies),
            "conflicts_found": {
                "keyword": len(kw_conflicts),
                "semantic": len(sem_conflicts),
                "smt": len(smt_conflicts),
                "llm": len(llm_conflicts),
                "hybrid": len(hybrid_conflicts),
            },
        }

    return results


def _keyword_overlap_baseline(policies: List[Dict]) -> List[Dict]:
    """Keyword overlap conflict detection baseline."""
    import itertools
    STOPWORDS = {"the", "a", "an", "is", "are", "in", "on", "to", "for", "of", "and", "or", "with", "by"}
    conflicts = []

    def policy_text(p):
        parts = []
        for c in p.get("conditions", []):
            parts.append(c.get("source_text") or str(c.get("value", "")))
        for a in p.get("actions", []):
            parts.append(a.get("source_text") or a.get("action", ""))
        return " ".join(parts).lower()

    for p1, p2 in itertools.combinations(policies, 2):
        words1 = set(policy_text(p1).split()) - STOPWORDS
        words2 = set(policy_text(p2).split()) - STOPWORDS
        overlap = words1 & words2
        if len(overlap) >= 3:
            conflicts.append({
                "policy_a": p1.get("policy_id", ""),
                "policy_b": p2.get("policy_id", ""),
                "conflict_detected": True,
                "conflict_type": "keyword_overlap",
                "confidence": len(overlap) / max(len(words1 | words2), 1),
                "explanation": f"Overlapping keywords: {', '.join(list(overlap)[:10])}",
            })
    return conflicts


def _semantic_similarity_baseline(policies: List[Dict]) -> List[Dict]:
    """Semantic similarity conflict detection baseline."""
    import itertools
    try:
        from sentence_transformers import SentenceTransformer
        import numpy as np
        model = SentenceTransformer("all-MiniLM-L6-v2")
    except ImportError:
        logger.warning("sentence-transformers not installed, skipping semantic baseline")
        return []

    def policy_text(p):
        parts = [str(p.get("scope", {}))]
        for c in p.get("conditions", []):
            parts.append(c.get("source_text") or str(c))
        for a in p.get("actions", []):
            parts.append(a.get("source_text") or a.get("action", ""))
        return " ".join(parts)

    texts = [policy_text(p) for p in policies]
    embeddings = model.encode(texts)
    conflicts = []

    for (i, p1), (j, p2) in itertools.combinations(enumerate(policies), 2):
        sim = float(np.dot(embeddings[i], embeddings[j]) /
                     (np.linalg.norm(embeddings[i]) * np.linalg.norm(embeddings[j]) + 1e-8))
        if sim >= 0.75:
            conflicts.append({
                "policy_a": p1.get("policy_id", ""),
                "policy_b": p2.get("policy_id", ""),
                "conflict_detected": True,
                "conflict_type": "semantic",
                "confidence": round(sim, 4),
                "explanation": f"Cosine similarity: {sim:.3f}",
            })
    return conflicts


def _llm_zeroshot_conflict(policies: List[Dict], llm: LLMClient) -> List[Dict]:
    """LLM zero-shot conflict detection baseline."""
    import itertools
    conflicts = []

    for p1, p2 in itertools.combinations(policies, 2):
        prompt = f"""Do these two policies conflict with each other?

Policy A ({p1.get('policy_id', '')}):
  Conditions: {json.dumps(p1.get('conditions', []))}
  Actions: {json.dumps(p1.get('actions', []))}

Policy B ({p2.get('policy_id', '')}):
  Conditions: {json.dumps(p2.get('conditions', []))}
  Actions: {json.dumps(p2.get('actions', []))}

Respond with JSON: {{"conflict": true/false, "type": "logical|semantic|none", "explanation": "..."}}"""

        try:
            result = llm.invoke_json(prompt)
            if result.get("conflict"):
                conflicts.append({
                    "policy_a": p1.get("policy_id", ""),
                    "policy_b": p2.get("policy_id", ""),
                    "conflict_detected": True,
                    "conflict_type": result.get("type", "unknown"),
                    "confidence": 0.8,
                    "explanation": result.get("explanation", ""),
                })
        except Exception as e:
            logger.warning("LLM conflict check failed for %s vs %s: %s",
                           p1.get("policy_id"), p2.get("policy_id"), e)

    return conflicts


# ==========================================================================
# Task 3: End-to-End Compliance
# ==========================================================================
def run_task3(
    bundle_path: str,
    queries_path: str,
    provider: str,
    model: str,
) -> Dict[str, Any]:
    """
    Run 7 methods on 2,000 queries.
    Directly calls Enforcement.enforce() for PolicyLLM.
    """
    # Load queries
    queries = []
    with open(queries_path) as f:
        for line in f:
            if line.strip():
                queries.append(json.loads(line))
    logger.info("Loaded %d queries", len(queries))

    # Load bundle
    bundle, index = load_bundle(bundle_path)

    # --- Method 1: vanilla_gpt4o ---
    _run_baseline_method("vanilla_gpt4o", queries, provider, model,
                         system_prompt="You are a helpful customer service agent.",
                         policies_injected=False)

    # --- Method 2: system_prompt_only ---
    all_rules_text = "\n".join(
        f"- {r.metadata.policy_id}: {r.metadata.source_text}"
        for r in bundle.conditional_rules
        if r.metadata and r.metadata.source_text
    )
    _run_baseline_method("system_prompt_only", queries, provider, model,
                         system_prompt=f"Follow these policies strictly:\n\n{all_rules_text}",
                         policies_injected=True)

    # --- Method 3: rag_only ---
    _run_baseline_method("rag_only", queries, provider, model,
                         system_prompt="Answer based on retrieved policies.",
                         policies_injected=True, use_rag=True, bundle=bundle, index=index)

    # --- Methods 4-6: nemo/llama_guard/wildguard ---
    # These require separate installations, log placeholder
    for method in ["nemo_guardrails", "llama_guard_3", "wildguard_7b"]:
        logger.info("Method %s requires manual setup — see guides/baseline_execution_guide.md", method)

    # --- Method 7: policyllm (full pipeline via Enforcement) ---
    _run_policyllm(queries, bundle, index, provider, model)

    return {"status": "complete", "n_queries": len(queries)}


def _run_baseline_method(
    method_name: str,
    queries: List[Dict],
    provider: str,
    model: str,
    system_prompt: str = "",
    policies_injected: bool = False,
    use_rag: bool = False,
    bundle=None,
    index=None,
):
    """Run a baseline method on all queries and save responses."""
    out_dir = RESULTS_DIR / "task3_e2e" / method_name
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "responses.jsonl"

    llm = LLMClient(provider=provider, model_id=model, temperature=0, max_tokens=2048)
    logger.info("Running %s on %d queries...", method_name, len(queries))

    with open(out_path, "w") as f:
        for i, q in enumerate(queries):
            start = time.perf_counter()
            try:
                prompt = f"{system_prompt}\n\nUser: {q['query_text']}" if system_prompt else q['query_text']
                result = llm.invoke_json(prompt)
                response_text = result if isinstance(result, str) else json.dumps(result)
                blocked = False
            except Exception as e:
                response_text = f"Error: {e}"
                blocked = True

            latency_ms = int((time.perf_counter() - start) * 1000)
            entry = {
                "query_id": q["query_id"],
                "response_text": response_text,
                "latency_ms": latency_ms,
                "blocked": blocked,
            }
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

            if (i + 1) % 100 == 0:
                logger.info("  %s: %d/%d", method_name, i + 1, len(queries))

    logger.info("  %s complete → %s", method_name, out_path)


def _run_policyllm(
    queries: List[Dict],
    bundle,
    index,
    provider: str,
    model: str,
):
    """Run full PolicyLLM enforcement pipeline on all queries."""
    out_dir = RESULTS_DIR / "task3_e2e" / "policyllm"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "responses.jsonl"

    llm = LLMClient(provider=provider, model_id=model, temperature=0, max_tokens=2048)
    config = EnforcementConfig()

    logger.info("Running PolicyLLM (full) on %d queries...", len(queries))

    with open(out_path, "w") as f:
        for i, q in enumerate(queries):
            start = time.perf_counter()
            try:
                decision = enforce(
                    query=q["query_text"],
                    bundle=bundle,
                    bundle_index=index,
                    llm_client=llm,
                    config=config,
                )
                response_text = decision.llm_response or ""
                blocked = decision.action.value in ("ESCALATE", "REGENERATE")
            except Exception as e:
                response_text = f"Error: {e}"
                blocked = True

            latency_ms = int((time.perf_counter() - start) * 1000)
            entry = {
                "query_id": q["query_id"],
                "response_text": response_text,
                "latency_ms": latency_ms,
                "blocked": blocked,
                "compliance_score": decision.score if not blocked else 0.0,
                "action": decision.action.value if hasattr(decision, "action") else "ERROR",
                "violations": decision.violations if hasattr(decision, "violations") else [],
            }
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

            if (i + 1) % 100 == 0:
                logger.info("  PolicyLLM: %d/%d", i + 1, len(queries))

    logger.info("  PolicyLLM complete → %s", out_path)


# ==========================================================================
# Ablation Study
# ==========================================================================
ABLATION_VARIANTS = {
    "full":             {"judge": True, "smt": True, "regex": True},
    "no_post_gen":      {"judge": False, "smt": False, "regex": False},
    "no_during_gen":    {"judge": True, "smt": True, "regex": True, "skip_during": True},
    "no_conflict":      {"judge": True, "smt": True, "regex": True, "skip_conflict": True},
    "no_smt":           {"judge": True, "smt": False, "regex": True},
    "pre_gen_only":     {"judge": False, "smt": False, "regex": False, "skip_during": True},
}


def run_ablation(
    bundle_path: str,
    queries_path: str,
    provider: str,
    model: str,
) -> Dict[str, Any]:
    """Run ablation variants on same query set."""
    queries = []
    with open(queries_path) as f:
        for line in f:
            if line.strip():
                queries.append(json.loads(line))

    bundle, index = load_bundle(bundle_path)
    llm = LLMClient(provider=provider, model_id=model, temperature=0, max_tokens=2048)

    results = {}

    for variant_name, flags in ABLATION_VARIANTS.items():
        out_dir = RESULTS_DIR / "ablation" / variant_name
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / "responses.jsonl"

        config = EnforcementConfig(
            judge_enabled=flags.get("judge", True),
            smt_enabled=flags.get("smt", True),
            regex_enabled=flags.get("regex", True),
        )

        logger.info("Ablation: %s (%d queries)...", variant_name, len(queries))

        compliant_count = 0
        total_latency = 0

        with open(out_path, "w") as f:
            for i, q in enumerate(queries):
                start = time.perf_counter()
                try:
                    decision = enforce(
                        query=q["query_text"],
                        bundle=bundle,
                        bundle_index=index,
                        llm_client=llm,
                        config=config,
                    )
                    response_text = decision.llm_response or ""
                    blocked = decision.action.value in ("ESCALATE", "REGENERATE")
                    score = decision.score
                except Exception as e:
                    response_text = f"Error: {e}"
                    blocked = True
                    score = 0.0

                latency_ms = int((time.perf_counter() - start) * 1000)
                total_latency += latency_ms
                if score >= 0.95:
                    compliant_count += 1

                entry = {
                    "query_id": q["query_id"],
                    "response_text": response_text,
                    "latency_ms": latency_ms,
                    "blocked": blocked,
                    "compliance_score": score,
                }
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

        n = len(queries)
        results[variant_name] = {
            "compliance_rate": round(compliant_count / n, 4) if n else 0,
            "avg_latency_ms": round(total_latency / n) if n else 0,
            "n_queries": n,
        }
        logger.info("  %s: compliance=%.1f%%, avg_latency=%dms",
                     variant_name, results[variant_name]["compliance_rate"] * 100,
                     results[variant_name]["avg_latency_ms"])

    # Save summary
    summary_path = RESULTS_DIR / "ablation" / "ablation_summary.json"
    with open(summary_path, "w") as f:
        json.dump(results, f, indent=2)
    logger.info("Ablation summary → %s", summary_path)

    return results


# ==========================================================================
# Metric computation (runs after experiments)
# ==========================================================================
def compute_task3_metrics(gt_judgments_path: str = None) -> Dict[str, Any]:
    """
    Compute compliance_rate, false_positive_rate, latency for all methods.
    Uses human judgments if available, else uses compliance_score threshold.
    """
    methods_dir = RESULTS_DIR / "task3_e2e"
    if not methods_dir.exists():
        return {}

    results = {}
    for method_dir in sorted(methods_dir.iterdir()):
        if not method_dir.is_dir():
            continue
        responses_path = method_dir / "responses.jsonl"
        if not responses_path.exists():
            continue

        responses = []
        with open(responses_path) as f:
            for line in f:
                if line.strip():
                    responses.append(json.loads(line))

        total = len(responses)
        if total == 0:
            continue

        # Skip warmup (first 50)
        eval_responses = responses[50:] if len(responses) > 50 else responses

        blocked = sum(1 for r in eval_responses if r.get("blocked"))
        compliant = sum(1 for r in eval_responses if r.get("compliance_score", 0) >= 0.95)
        latencies = [r["latency_ms"] for r in eval_responses if "latency_ms" in r]

        n = len(eval_responses)
        results[method_dir.name] = {
            "total": n,
            "compliance_rate": round(compliant / n, 4) if n else 0,
            "false_positive_rate": round(blocked / n, 4) if n else 0,
            "median_latency_ms": sorted(latencies)[len(latencies)//2] if latencies else 0,
            "p95_latency_ms": sorted(latencies)[int(len(latencies)*0.95)] if latencies else 0,
        }

    return results


# ==========================================================================
# Main CLI
# ==========================================================================
def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s — %(message)s")

    parser = argparse.ArgumentParser(description="PolicyLLM Evaluation Runner")
    parser.add_argument("--task", required=True,
                        choices=["task1", "task2", "task3", "ablation", "metrics", "all"],
                        help="Which experiment to run")
    parser.add_argument("--provider", default="chatgpt", help="LLM provider")
    parser.add_argument("--model", default="gpt-4o-mini", help="Model ID")
    parser.add_argument("--docs-dir", default="Evaluation/data/company_policies", help="Company docs directory")
    parser.add_argument("--bundle", default=None, help="Path to compiled_policy_bundle.json")
    parser.add_argument("--queries", default="Evaluation/data/test_queries.jsonl", help="Test queries path")
    args = parser.parse_args()

    if args.task in ("task1", "all"):
        logger.info("========== Task 1: Extraction ==========")
        run_task1(args.docs_dir, args.provider, args.model)

    if args.task in ("task2", "all"):
        logger.info("========== Task 2: Conflict Detection ==========")
        run_task2(args.provider, args.model)

    if args.task in ("task3", "all"):
        if not args.bundle:
            logger.error("--bundle required for task3")
            sys.exit(1)
        logger.info("========== Task 3: End-to-End Compliance ==========")
        run_task3(args.bundle, args.queries, args.provider, args.model)

    if args.task in ("ablation", "all"):
        if not args.bundle:
            logger.error("--bundle required for ablation")
            sys.exit(1)
        logger.info("========== Ablation Study ==========")
        run_ablation(args.bundle, args.queries, args.provider, args.model)

    if args.task in ("metrics", "all"):
        logger.info("========== Computing Metrics ==========")
        metrics = compute_task3_metrics()
        print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
