# Evaluation Module (Group 4)

## Full Experiment Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    EXPERIMENT PIPELINE                          │
│                                                                 │
│  Phase 1: Data Preparation (Week 3-4)                          │
│  ┌──────────┐    ┌──────────┐    ┌───────────────┐             │
│  │ Company  │    │DecisionsDev│   │ 2,000 Test   │             │
│  │ Policy   │    │ CSV Logs  │   │ Queries      │             │
│  │ Documents │    │ (3 domains)│   │ (generated)  │             │
│  └────┬─────┘    └─────┬─────┘   └──────┬───────┘             │
│       │                │                 │                      │
│  Phase 2: Module Execution (Week 5-6)                          │
│       │                │                 │                      │
│       ▼                ▼                 │                      │
│  ┌─────────┐    ┌──────────┐             │                     │
│  │Extractor│    │FP-Growth │             │                     │
│  │(6-pass) │    │Rule Mine │             │                     │
│  └────┬────┘    └─────┬────┘             │                     │
│       │               │                  │                      │
│       ▼               ▼                  │                      │
│  ┌──────────────────────┐                │                     │
│  │   Stage 1 JSON       │                │                     │
│  │   (explicit+implicit)│                │                     │
│  └──────────┬───────────┘                │                     │
│             │                            │                      │
│             ▼                            │                      │
│  ┌──────────────────────┐                │                     │
│  │   Validation         │                │                     │
│  │   (IR→DAG→Z3→Bundle) │                │                     │
│  └──────────┬───────────┘                │                     │
│             │                            │                      │
│             ▼                            ▼                      │
│  ┌──────────────────────────────────────────┐                  │
│  │   Enforcement                             │                  │
│  │   (Pre-Gen→During-Gen→Post-Gen→Decision)  │                  │
│  │   × 7 methods × 2,000 queries             │                  │
│  └──────────┬───────────────────────────────┘                  │
│             │                                                   │
│  Phase 3: Evaluation (Week 6-7)                                │
│             │                                                   │
│             ▼                                                   │
│  ┌──────────────────────────────────────────┐                  │
│  │   Evaluation                              │                  │
│  │   Task 1: Extraction F1                   │                  │
│  │   Task 2: Conflict Detection F1           │                  │
│  │   Task 3: Compliance Rate / FP / Latency  │                  │
│  │   Ablation: Module contribution analysis  │                  │
│  └──────────────────────────────────────────┘                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Commands (from PolicyLLM root)

### Step 0: Prepare Data

```bash
# DecisionsDev implicit policy mining
python -m Evaluation.scripts.01_setup_decisionsDev --repo-path ./policy-corpus
python -m Evaluation.scripts.02_implicit_eval --domain all --size large

# Generate 2,000 test queries
python -m Evaluation.scripts.03_generate_test_queries
```

### Step 1: Run Full Pipeline on Sample Doc (smoke test)

```bash
python main.py run tests/data/sample_policy.md \
    --query "Can I return my phone without a receipt?" \
    --provider chatgpt --model gpt-4o-mini
```

### Step 2: Run Experiments via Evaluation Runner

```bash
# Task 1: Extraction baselines + ours
python -m Evaluation.runner --task task1 --provider chatgpt --model gpt-4o

# Task 2: Conflict detection baselines + ours
python -m Evaluation.runner --task task2 --provider chatgpt --model gpt-4o

# Task 3: E2E compliance (requires bundle)
python -m Evaluation.runner --task task3 \
    --bundle output/compiled_policy_bundle.json \
    --queries Evaluation/data/test_queries.jsonl \
    --provider chatgpt --model gpt-4o

# Ablation study
python -m Evaluation.runner --task ablation \
    --bundle output/compiled_policy_bundle.json \
    --queries Evaluation/data/test_queries.jsonl \
    --provider chatgpt --model gpt-4o

# Compute final metrics
python -m Evaluation.runner --task metrics
```

### Step 3: Annotation & Agreement

```bash
# After collecting responses, measure inter-annotator agreement
python -m Evaluation.scripts.04_annotation_agreement
```

## What runner.py Does Internally

| Task | What it calls | Output |
|------|--------------|--------|
| task1 | `Extractor.src.pipeline.run_pipeline()` (ours) + zero-shot/schema baselines | `results/task1_extraction/{method}/{company}/policies.json` |
| task2 | `Validation.conflict_detector.detect_conflicts()` (SMT) + keyword/semantic/LLM baselines | `results/task2_conflict/{method}/{company}/conflicts.json` |
| task3 | `Enforcement.enforce()` (PolicyLLM) + vanilla/system_prompt/RAG baselines | `results/task3_e2e/{method}/responses.jsonl` |
| ablation | `Enforcement.enforce()` with `EnforcementConfig` flags toggled | `results/ablation/{variant}/responses.jsonl` |
| metrics | Reads all responses, computes compliance/FP/latency | stdout JSON |

## Directory Structure

```
PolicyLLM/
├── Extractor/                 ← Group 1 (imported by runner.py)
├── Validation/                ← Group 2 (imported by runner.py)
├── Enforcement/               ← Group 3 (imported by runner.py)
├── Evaluation/                ← Group 4 (this module)
│   ├── __init__.py
│   ├── runner.py              ← Main experiment orchestrator
│   ├── scripts/
│   │   ├── 01_setup_decisionsDev.py
│   │   ├── 02_implicit_eval.py
│   │   ├── 03_generate_test_queries.py
│   │   └── 04_annotation_agreement.py
│   ├── configs/
│   │   ├── decisionsDev_config.yaml
│   │   ├── experiment_config.yaml
│   │   └── query_generation_config.yaml
│   ├── guides/
│   │   ├── baseline_execution_guide.md
│   │   └── ablation_execution_guide.md
│   ├── annotation/
│   │   ├── protocol.md
│   │   └── protocol_decisionsDev.md
│   ├── data/
│   │   ├── decisionsDev/          ← Implicit policy data
│   │   ├── company_policies/      ← 6 company docs (from Person 1)
│   │   └── test_queries.jsonl     ← 2,000 generated queries
│   └── results/
│       ├── task1_extraction/
│       ├── task2_conflict/
│       ├── task3_e2e/
│       └── ablation/
├── evals/                     ← Group 3's existing eval (kept)
├── tests/
└── main.py
```
