"""Evaluation (Group 4) — Experiment orchestration, baseline comparison, and ablation."""
