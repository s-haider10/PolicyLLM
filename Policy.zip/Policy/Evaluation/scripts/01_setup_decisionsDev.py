#!/usr/bin/env python3
"""
01_setup_decisionsDev.py

Setup and validate the DecisionsDev corpus.
Parses the actual CSV format (nested JSON columns) into flat tabular data
ready for FP-Growth rule mining.

Prerequisites:
    git clone https://github.com/DecisionsDev/policy-corpus.git

Usage:
    python scripts/01_setup_decisionsDev.py --repo-path /path/to/policy-corpus
    python scripts/01_setup_decisionsDev.py --repo-path /path/to/policy-corpus --domain luggage
"""

import argparse
import ast
import csv
import io
import json
import os
import sys
from pathlib import Path
from datetime import datetime, date

import yaml
import pandas as pd

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "configs" / "decisionsDev_config.yaml"
DATA_DIR = ROOT / "data" / "decisionsDev"

DOMAINS = ["luggage", "insurance", "loan"]


def load_config() -> dict:
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Step 1: Validate repo
# ---------------------------------------------------------------------------
def validate_repo(repo_path: Path, domain: str = None) -> dict:
    """Check all expected files exist in the cloned repo."""
    config = load_config()
    targets = [domain] if domain else DOMAINS
    results = {}

    for d in targets:
        dc = config["domains"][d]
        found = {}
        missing = []

        for key in ["policy_spec", "reference_impl", "data_generator"]:
            p = repo_path / dc[key]
            if p.exists():
                found[key] = str(p)
            elif key == "policy_spec" and (repo_path / dc.get("policy_spec_alt", "")).exists():
                found[key] = str(repo_path / dc["policy_spec_alt"])
            else:
                missing.append(key)

        for size_key, rel_path in dc["decisions"].items():
            p = repo_path / rel_path
            if p.exists():
                found[f"decisions_{size_key}"] = str(p)
            else:
                missing.append(f"decisions_{size_key}")

        status = "ok" if not missing else "incomplete"
        results[d] = {"status": status, "found": found, "missing": missing}

        icon = "✓" if status == "ok" else "✗"
        print(f"  [{icon}] {d}: {status}")
        if missing:
            print(f"      Missing: {', '.join(missing)}")

    return results


# ---------------------------------------------------------------------------
# Step 2: Parse CSVs — domain-specific flatteners
# ---------------------------------------------------------------------------
def parse_json_cell(cell: str):
    """Safely parse a JSON string from a CSV cell."""
    if pd.isna(cell) or cell == "" or cell == '""':
        return None
    try:
        return json.loads(cell)
    except json.JSONDecodeError:
        try:
            return ast.literal_eval(cell)
        except (ValueError, SyntaxError):
            return None


def compute_age(birth_date_str: str) -> int:
    """Compute age from birth date string."""
    try:
        bd = datetime.strptime(birth_date_str, "%Y-%m-%d").date()
        today = date.today()
        return today.year - bd.year - ((today.month, today.day) < (bd.month, bd.day))
    except (ValueError, TypeError):
        return -1


# ---- LUGGAGE ----
def flatten_luggage(df: pd.DataFrame) -> pd.DataFrame:
    """
    Flatten luggage CSV into tabular format.

    Input per row:
      travel_class, age_category, luggages(JSON array), eligibility, fees, ...

    Output per row (one row per luggage item):
      travel_class, age_category, storage, weight, excess, special,
      height, width, depth, item_compliance,
      [row-level] eligibility, fees
    """
    rows = []
    for idx, row in df.iterrows():
        luggages = parse_json_cell(row.get("luggages", "[]"))
        if not luggages:
            continue

        # Count luggage by type
        n_carryon = sum(1 for l in luggages if l.get("storage") == "carry-on")
        n_checked = sum(1 for l in luggages if l.get("storage") == "checked")
        total_weight = sum(l.get("weight", 0) for l in luggages)
        max_weight = max((l.get("weight", 0) for l in luggages), default=0)
        has_excess = any(l.get("excess", False) for l in luggages)
        has_special = any(l.get("special", False) for l in luggages)

        flat = {
            "travel_class": row.get("travel_class", ""),
            "age_category": row.get("age_category", ""),
            "n_carryon": n_carryon,
            "n_checked": n_checked,
            "n_total": len(luggages),
            "total_weight": round(total_weight, 2),
            "max_weight": round(max_weight, 2),
            "has_excess": has_excess,
            "has_special": has_special,
            # Decision columns
            "eligibility": row.get("eligibility"),
            "compliance_result": row.get("compliance_result"),
            "fees": row.get("fees"),
        }
        rows.append(flat)

    return pd.DataFrame(rows)


# ---- INSURANCE ----
def flatten_insurance(df: pd.DataFrame) -> pd.DataFrame:
    """
    Flatten insurance CSV.

    Input: applicants(JSON array), vehicle(JSON), eligible, premium_fee, reason
    Output: primary applicant features + decision
    """
    rows = []
    for idx, row in df.iterrows():
        applicants = parse_json_cell(row.get("applicants", "[]"))
        if not applicants:
            continue

        # Extract primary holder
        primary = next((a for a in applicants if a.get("is_primary_holder")), applicants[0])
        n_applicants = len(applicants)
        n_with_violations = sum(
            1 for a in applicants
            if a.get("driving_history") and len(a["driving_history"]) > 0
        )
        n_with_fraud = sum(
            1 for a in applicants
            for cov in a.get("history_insurance_coverage", [])
            if cov.get("fraud", False)
        )
        n_with_lapse = sum(
            1 for a in applicants
            for cov in a.get("history_insurance_coverage", [])
            if cov.get("lapse", False)
        )
        total_claims = sum(
            cov.get("claims", 0)
            for a in applicants
            for cov in a.get("history_insurance_coverage", [])
        )

        license_info = primary.get("driving_license", {})

        flat = {
            "n_applicants": n_applicants,
            "primary_age": compute_age(primary.get("birth_date", "")),
            "primary_credit_score": primary.get("credit_score", 0),
            "primary_license_status": license_info.get("status", "unknown"),
            "primary_license_country": license_info.get("issue_country", "unknown"),
            "primary_state": primary.get("address", {}).get("state", "unknown"),
            "primary_n_violations": len(primary.get("driving_history", [])),
            "total_n_violations": sum(len(a.get("driving_history", [])) for a in applicants),
            "n_with_violations": n_with_violations,
            "n_with_fraud": n_with_fraud,
            "n_with_lapse": n_with_lapse,
            "total_claims": total_claims,
            # Decision
            "eligible": row.get("eligible"),
            "premium_fee": row.get("premium_fee"),
            "reason": row.get("reason", ""),
        }
        rows.append(flat)

    return pd.DataFrame(rows)


# ---- LOAN ----
def flatten_loan(df: pd.DataFrame) -> pd.DataFrame:
    """
    Flatten loan CSV.

    Input: applicant(JSON), co_signer(JSON), loan_amount, eligibility, interest_rate, reason
    Output: flat applicant features + decision
    """
    rows = []
    for idx, row in df.iterrows():
        applicant = parse_json_cell(row.get("applicant", "{}"))
        co_signer = parse_json_cell(row.get("co_signer", ""))

        if not applicant:
            continue

        has_cosigner = co_signer is not None and co_signer != ""
        monthly_debt = applicant.get("monthly_debt_amount", 0)
        monthly_income = applicant.get("monthly_gross_income", 1)
        dti = round(monthly_debt / monthly_income, 4) if monthly_income > 0 else 999

        flat = {
            "age": compute_age(applicant.get("birth_date", "")),
            "country": applicant.get("address", {}).get("country", "unknown"),
            "credit_score": applicant.get("credit_score", 0),
            "annual_income": applicant.get("annual_income", 0),
            "income_document": applicant.get("income_document", "none"),
            "employment_status": applicant.get("employment_status", "unknown"),
            "has_financial_record": applicant.get("is_financial_record_present", False),
            "monthly_debt": monthly_debt,
            "monthly_income": monthly_income,
            "debt_to_income": dti,
            "loan_amount": row.get("loan_amount", 0),
            "has_cosigner": has_cosigner,
            # Co-signer features (if present)
            "cosigner_credit_score": co_signer.get("credit_score", 0) if isinstance(co_signer, dict) else 0,
            # Decision
            "eligibility": row.get("eligibility"),
            "interest_rate": row.get("interest_rate"),
            "reason": row.get("reason", ""),
        }
        rows.append(flat)

    return pd.DataFrame(rows)


FLATTENERS = {
    "luggage": flatten_luggage,
    "insurance": flatten_insurance,
    "loan": flatten_loan,
}


# ---------------------------------------------------------------------------
# Step 3: Load and flatten
# ---------------------------------------------------------------------------
def load_and_flatten(repo_path: Path, domain: str, size: str = "small") -> pd.DataFrame:
    """Load a domain's CSV and flatten it."""
    config = load_config()
    dc = config["domains"][domain]
    csv_path = repo_path / dc["decisions"][size]

    print(f"  Loading {csv_path.name} ...")
    df = pd.read_csv(csv_path)
    print(f"  Raw: {len(df)} rows, {len(df.columns)} columns")

    flattener = FLATTENERS[domain]
    flat_df = flattener(df)
    print(f"  Flat: {len(flat_df)} rows, {len(flat_df.columns)} columns")
    print(f"  Columns: {list(flat_df.columns)}")

    return flat_df


# ---------------------------------------------------------------------------
# Step 4: Save processed data
# ---------------------------------------------------------------------------
def process_and_save(repo_path: Path, domain: str):
    """Load, flatten, and save as clean CSV + eval split."""
    domain_dir = DATA_DIR / domain
    domain_dir.mkdir(parents=True, exist_ok=True)

    config = load_config()
    dc = config["domains"][domain]

    for size in config["implicit_eval"]["dataset_sizes"]:
        csv_rel = dc["decisions"].get(size)
        if not csv_rel:
            continue
        csv_path = repo_path / csv_rel
        if not csv_path.exists():
            print(f"  [SKIP] {domain}/{size}: file not found")
            continue

        flat_df = load_and_flatten(repo_path, domain, size)

        # Save flattened (system_input — what the extraction pipeline receives)
        sys_dir = domain_dir / "system_input"
        sys_dir.mkdir(parents=True, exist_ok=True)
        flat_path = sys_dir / f"decisions_flat_{size}.csv"
        flat_df.to_csv(flat_path, index=False)
        print(f"  Saved: {flat_path}")

    # Copy ground truth (policy spec + reference impl)
    gt_dir = domain_dir / "ground_truth"
    gt_dir.mkdir(parents=True, exist_ok=True)

    import shutil
    for key in ["policy_spec", "policy_spec_alt", "reference_impl"]:
        rel = dc.get(key)
        if rel:
            src = repo_path / rel
            if src.exists():
                dst = gt_dir / src.name
                shutil.copy2(src, dst)
                print(f"  GT copied: {src.name}")


# ---------------------------------------------------------------------------
# Step 5: Summary
# ---------------------------------------------------------------------------
def write_summary(repo_path: Path, validation: dict):
    """Write corpus summary."""
    config = load_config()
    summary = {
        "corpus": "DecisionsDev/policy-corpus",
        "license": config["corpus"]["license"],
        "repo_path": str(repo_path),
        "domains": {},
    }

    for domain, v in validation.items():
        dc = config["domains"][domain]
        # Check what flattened data we have
        flat_files = list((DATA_DIR / domain / "system_input").glob("*.csv")) if (DATA_DIR / domain / "system_input").exists() else []

        summary["domains"][domain] = {
            "status": v["status"],
            "artifacts": v["found"],
            "missing": v["missing"],
            "decision_variable": dc["decision_variable"],
            "key_variables": dc["key_variables"],
            "flattened_files": [str(f.name) for f in flat_files],
        }

    out = DATA_DIR / "corpus_summary.json"
    with open(out, "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"\n  Summary → {out}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Setup DecisionsDev corpus")
    parser.add_argument("--repo-path", type=str, required=True,
                        help="Path to cloned policy-corpus directory")
    parser.add_argument("--domain", type=str, default=None,
                        help="Process specific domain only")
    args = parser.parse_args()

    repo_path = Path(args.repo_path).resolve()
    if not repo_path.exists():
        print(f"ERROR: repo path not found: {repo_path}")
        sys.exit(1)

    print("=" * 60)
    print("DecisionsDev Corpus Setup")
    print(f"Repo: {repo_path}")
    print("=" * 60)

    # Step 1: Validate
    print("\n[Step 1] Validating artifacts...")
    validation = validate_repo(repo_path, args.domain)

    # Step 2-4: Parse and flatten
    targets = [args.domain] if args.domain else DOMAINS
    for d in targets:
        print(f"\n[Step 2-4] Processing {d}...")
        try:
            process_and_save(repo_path, d)
        except Exception as e:
            print(f"  [ERROR] {d}: {e}")
            import traceback
            traceback.print_exc()

    # Step 5: Summary
    print("\n[Step 5] Writing summary...")
    write_summary(repo_path, validation)

    print("\n" + "=" * 60)
    print("Setup complete!")
    print("Next: python scripts/02_implicit_eval.py --domain all")
    print("=" * 60)


if __name__ == "__main__":
    main()
