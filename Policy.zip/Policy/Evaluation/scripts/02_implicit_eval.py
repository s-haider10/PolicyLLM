#!/usr/bin/env python3
"""
02_implicit_eval.py  (v2 — bugfixed)

FP-Growth on DecisionsDev decision logs → Stage 1 JSON (exact schema).

Fixes from v1:
  - No double prefix on boolean/categorical columns
  - Decision columns excluded from antecedent (no decision→decision rules)
  - fees column properly discretized
  - Output conforms to Output_Format_Definition Stage 1 schema

Usage:
    python scripts/02_implicit_eval.py --domain all
    python scripts/02_implicit_eval.py --domain loan --size large
"""

import argparse
import json
from pathlib import Path

import yaml
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "configs" / "decisionsDev_config.yaml"
DATA_DIR = ROOT / "data" / "decisionsDev"
RESULTS_DIR = ROOT / "results"
DOMAINS = ["luggage", "insurance", "loan"]


def load_config() -> dict:
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Step 1: Load
# ---------------------------------------------------------------------------
def load_flat_data(domain: str, size: str = "small") -> pd.DataFrame:
    path = DATA_DIR / domain / "system_input" / f"decisions_flat_{size}.csv"
    if not path.exists():
        raise FileNotFoundError(f"{path} not found. Run 01_setup first.")
    df = pd.read_csv(path)
    print(f"  Loaded {len(df)} rows from {path.name}")
    return df


# ---------------------------------------------------------------------------
# Step 2: Discretize  (FIXED: no double prefix)
# ---------------------------------------------------------------------------
BINS_CONFIG = {
    "n_carryon": ([0, 1, 2, 99], ["0-1", "1-2", "2+"]),
    "n_checked": ([0, 1, 2, 3, 99], ["0-1", "1-2", "2-3", "3+"]),
    "n_total": ([0, 2, 4, 6, 99], ["0-2", "2-4", "4-6", "6+"]),
    "total_weight": ([0, 20, 40, 60, 100, 999], ["0-20", "20-40", "40-60", "60-100", "100+"]),
    "max_weight": ([0, 10, 23, 32, 50, 999], ["0-10", "10-23", "23-32", "32-50", "50+"]),
    "fees": ([float("-inf"), 0, 1, 50, 100, 999], ["0", "0-1", "1-50", "50-100", "100+"]),
    "primary_age": ([0, 18, 25, 35, 50, 65, 999], ["<18", "18-25", "25-35", "35-50", "50-65", "65+"]),
    "primary_credit_score": ([0, 300, 580, 670, 740, 800, 850], ["<300", "300-580", "580-670", "670-740", "740-800", "800+"]),
    "primary_n_violations": ([float("-inf"), 0, 1, 2, 99], ["0", "1", "2", "3+"]),
    "total_n_violations": ([float("-inf"), 0, 1, 3, 5, 99], ["0", "1-3", "3-5", "5+"]),
    "total_claims": ([float("-inf"), 0, 1, 2, 5, 99], ["0", "1", "2-5", "5+"]),
    "n_applicants": ([0, 1, 2, 3, 99], ["1", "2", "3", "4+"]),
    "premium_fee": ([float("-inf"), 0, 500, 1000, 2000, 5000, 999999], ["0", "0-500", "500-1K", "1K-2K", "2K-5K", "5K+"]),
    "age": ([0, 18, 25, 35, 50, 65, 999], ["<18", "18-25", "25-35", "35-50", "50-65", "65+"]),
    "credit_score": ([0, 300, 580, 670, 740, 800, 850], ["<300", "300-580", "580-670", "670-740", "740-800", "800+"]),
    "annual_income": ([0, 30000, 50000, 75000, 100000, 150000, 9999999], ["<30K", "30-50K", "50-75K", "75-100K", "100-150K", "150K+"]),
    "monthly_debt": ([float("-inf"), 0, 200, 500, 1000, 2000, 99999], ["0", "0-200", "200-500", "500-1K", "1K-2K", "2K+"]),
    "monthly_income": ([0, 3000, 5000, 10000, 20000, 99999], ["<3K", "3-5K", "5-10K", "10-20K", "20K+"]),
    "debt_to_income": ([0, 0.1, 0.2, 0.36, 0.43, 0.5, 999], ["<0.1", "0.1-0.2", "0.2-0.36", "0.36-0.43", "0.43-0.5", "0.5+"]),
    "loan_amount": ([0, 5000, 10000, 25000, 50000, 100000, 9999999], ["<5K", "5-10K", "10-25K", "25-50K", "50-100K", "100K+"]),
    "cosigner_credit_score": ([0, 300, 580, 670, 740, 800, 850], ["<300", "300-580", "580-670", "670-740", "740-800", "800+"]),
    "interest_rate": ([0, 5, 8, 10, 13, 15, 20, 100], ["<5%", "5-8%", "8-10%", "10-13%", "13-15%", "15-20%", "20%+"]),
}


def discretize(df: pd.DataFrame, decision_cols: list[str]) -> tuple[pd.DataFrame, list[str]]:
    """
    Discretize continuous features. Returns (discretized_df, input_column_names).
    All cell values are prefixed ONCE as "col=value".
    """
    df = df.copy()
    processed = set()

    # 1) Bin numeric columns that have a config entry
    for col, (bins, labels) in BINS_CONFIG.items():
        if col in df.columns:
            prefixed_labels = [f"{col}={lbl}" for lbl in labels]
            df[col] = pd.cut(df[col], bins=bins, labels=prefixed_labels, include_lowest=True)
            processed.add(col)

    # 2) Boolean → "col=True" / "col=False"
    for col in df.columns:
        if col in processed:
            continue
        if df[col].dtype == "bool" or set(df[col].dropna().unique()).issubset({True, False, "True", "False"}):
            df[col] = df[col].apply(lambda x: f"{col}={x}" if pd.notna(x) else None)
            processed.add(col)

    # 3) Remaining categorical/object → "col=value"
    for col in df.columns:
        if col in processed:
            continue
        if df[col].dtype == "object" or df[col].dtype.name == "category":
            df[col] = df[col].apply(lambda x: f"{col}={x}" if pd.notna(x) else None)
            processed.add(col)

    # 4) Any unprocessed numeric (no bin config) → auto-bin into quartiles
    for col in df.columns:
        if col in processed:
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            try:
                df[col] = pd.qcut(df[col], q=4, duplicates="drop").apply(
                    lambda x: f"{col}={x}" if pd.notna(x) else None
                )
            except ValueError:
                df[col] = df[col].apply(lambda x: f"{col}={x}" if pd.notna(x) else None)
            processed.add(col)

    input_cols = [c for c in df.columns if c not in decision_cols and c != "reason"]
    return df, input_cols


# ---------------------------------------------------------------------------
# Step 3: FP-Growth  (FIXED: decision cols excluded from antecedent)
# ---------------------------------------------------------------------------
def run_fpgrowth(
    df: pd.DataFrame,
    input_cols: list[str],
    decision_cols: list[str],
    min_support_ratio: float = 0.05,
    min_confidence: float = 0.8,
) -> list[dict]:
    """Run FP-Growth. Only rules with input→decision are kept."""
    try:
        from mlxtend.frequent_patterns import fpgrowth, association_rules
        from mlxtend.preprocessing import TransactionEncoder
    except ImportError:
        print("  [ERROR] pip install mlxtend")
        return []

    # Build transactions
    all_cols = input_cols + decision_cols
    transactions = []
    for _, row in df.iterrows():
        items = []
        for col in all_cols:
            val = row.get(col)
            if pd.notna(val) and val is not None:
                items.append(str(val))
        if items:
            transactions.append(items)

    print(f"  Transactions: {len(transactions)}, unique items: {len(set(i for t in transactions for i in t))}")

    te = TransactionEncoder()
    te_array = te.fit_transform(transactions)
    encoded_df = pd.DataFrame(te_array, columns=te.columns_)

    print(f"  Running FP-Growth (min_support={min_support_ratio})...")
    freq_items = fpgrowth(encoded_df, min_support=min_support_ratio, use_colnames=True)
    print(f"  Frequent itemsets: {len(freq_items)}")

    if freq_items.empty:
        return []

    rules = association_rules(freq_items, metric="confidence", min_threshold=min_confidence)
    print(f"  Raw rules: {len(rules)}")

    if rules.empty:
        return []

    # Build prefix sets for filtering
    decision_prefixes = tuple(f"{c}=" for c in decision_cols)
    input_prefixes = tuple(f"{c}=" for c in input_cols)

    filtered = []
    for _, rule in rules.iterrows():
        antecedent = list(rule["antecedents"])
        consequent = list(rule["consequents"])

        # FILTER 1: Consequent must be a decision column
        cons_is_decision = all(
            str(item).startswith(decision_prefixes) for item in consequent
        )
        if not cons_is_decision:
            continue

        # FILTER 2: Antecedent must be ONLY input columns (no decision→decision)
        ant_is_input = all(
            str(item).startswith(input_prefixes) for item in antecedent
        )
        if not ant_is_input:
            continue

        # FILTER 3: Must have at least 1 antecedent condition
        if not antecedent:
            continue

        filtered.append({
            "antecedent": sorted(antecedent),
            "consequent": sorted(consequent),
            "confidence": round(float(rule["confidence"]), 4),
            "support": round(float(rule["support"]), 4),
            "support_count": int(rule["support"] * len(df)),
            "lift": round(float(rule["lift"]), 4),
        })

    filtered.sort(key=lambda x: (-x["confidence"], -x["lift"], -x["support"]))

    # Deduplicate (same antecedent+consequent)
    seen = set()
    unique = []
    for r in filtered:
        key = (tuple(r["antecedent"]), tuple(r["consequent"]))
        if key not in seen:
            seen.add(key)
            unique.append(r)

    print(f"  Valid input→decision rules: {len(unique)}")
    return unique


# ---------------------------------------------------------------------------
# Step 4: Convert to Stage 1 JSON (exact schema)
# ---------------------------------------------------------------------------
def parse_item(item: str) -> tuple[str, str]:
    """Parse 'col=value' into (col, value). Handles 'col=a-b' ranges."""
    parts = item.split("=", 1)
    return parts[0], parts[1] if len(parts) > 1 else ""


# Map DecisionsDev variables to condition types
CONDITION_TYPE_MAP = {
    # luggage
    "travel_class": "customer_tier",
    "age_category": "customer_tier",
    "n_carryon": "amount_threshold",
    "n_checked": "amount_threshold",
    "n_total": "amount_threshold",
    "total_weight": "amount_threshold",
    "max_weight": "amount_threshold",
    "has_excess": "boolean_flag",
    "has_special": "boolean_flag",
    # insurance
    "primary_age": "amount_threshold",
    "primary_credit_score": "amount_threshold",
    "primary_license_status": "boolean_flag",
    "primary_license_country": "geographic",
    "primary_state": "geographic",
    "primary_n_violations": "amount_threshold",
    "total_n_violations": "amount_threshold",
    "n_with_violations": "amount_threshold",
    "n_with_fraud": "amount_threshold",
    "n_with_lapse": "amount_threshold",
    "total_claims": "amount_threshold",
    "n_applicants": "amount_threshold",
    # loan
    "age": "amount_threshold",
    "country": "geographic",
    "credit_score": "amount_threshold",
    "annual_income": "amount_threshold",
    "income_document": "product_category",
    "employment_status": "customer_tier",
    "has_financial_record": "boolean_flag",
    "monthly_debt": "amount_threshold",
    "monthly_income": "amount_threshold",
    "debt_to_income": "amount_threshold",
    "loan_amount": "amount_threshold",
    "has_cosigner": "boolean_flag",
    "cosigner_credit_score": "amount_threshold",
}

DOMAIN_MAP = {
    "luggage": "LUGGAGE",
    "insurance": "INSURANCE",
    "loan": "LOAN",
}


def build_condition(col: str, value: str) -> dict:
    """Build a Stage 1 condition object from a discretized item."""
    cond_type = CONDITION_TYPE_MAP.get(col, "inferred")

    # Parse range values like "20-40" or "<18" or "65+"
    if "-" in value and not value.startswith("<"):
        parts = value.replace("+", "").replace("K", "000").replace("%", "").split("-")
        try:
            low = float(parts[0])
            high = float(parts[1]) if len(parts) > 1 else None
            return {
                "type": cond_type,
                "value": low,
                "value_high": high,
                "unit": infer_unit(col),
                "operator": "range",
                "target": col,
                "source_text": None
            }
        except ValueError:
            pass

    if value.startswith("<"):
        try:
            num = float(value[1:].replace("K", "000").replace("%", ""))
            return {
                "type": cond_type,
                "value": num,
                "unit": infer_unit(col),
                "operator": "<",
                "target": col,
                "source_text": None
            }
        except ValueError:
            pass

    if value.endswith("+"):
        try:
            num = float(value[:-1].replace("K", "000").replace("%", ""))
            return {
                "type": cond_type,
                "value": num,
                "unit": infer_unit(col),
                "operator": ">=",
                "target": col,
                "source_text": None
            }
        except ValueError:
            pass

    # Boolean
    if value.lower() in ("true", "false"):
        return {
            "type": "boolean_flag",
            "value": value.lower() == "true",
            "parameter": col,
            "operator": "==",
            "target": col,
            "source_text": None
        }

    # Categorical
    return {
        "type": cond_type,
        "value": value,
        "operator": "==",
        "target": col,
        "source_text": None
    }


def infer_unit(col: str) -> str:
    """Infer unit from column name."""
    if "weight" in col:
        return "kg"
    if "income" in col or "debt" in col or "amount" in col or "fee" in col or "premium" in col:
        return "USD"
    if "age" in col:
        return "years"
    if "rate" in col:
        return "percent"
    if "score" in col:
        return "points"
    return ""


def rules_to_stage1_json(rules: list[dict], domain: str, size: str) -> list[dict]:
    """Convert FP-Growth rules to exact Stage 1 JSON schema."""
    policies = []
    domain_upper = DOMAIN_MAP.get(domain, domain.upper())

    for i, rule in enumerate(rules):
        # Build conditions
        conditions = []
        for item in rule["antecedent"]:
            col, val = parse_item(item)
            conditions.append(build_condition(col, val))

        # Build actions
        actions = []
        for item in rule["consequent"]:
            col, val = parse_item(item)
            actions.append({
                "type": "discovered_pattern",
                "action": f"{col}_{val}".replace(" ", "_").replace("+", "plus"),
                "requires": [c["target"] for c in conditions],
                "source_text": None
            })

        # Build scope (implicit = broad scope, refined by conditions)
        scope = {
            "customer_segments": ["all"],
            "product_categories": ["all"],
            "channels": ["all"],
            "regions": ["all"]
        }

        # Narrow scope based on conditions
        for c in conditions:
            if c["target"] in ("travel_class", "age_category", "employment_status"):
                scope["customer_segments"] = [str(c["value"])]
            if c["target"] in ("primary_state", "country"):
                scope["regions"] = [str(c["value"])]

        policy = {
            "schema_version": "1.0",
            "processing_status": {
                "extraction": "complete",
                "formalization": "pending",
                "conflict_detection": "pending",
                "layer_assignment": "pending"
            },
            "policy_id": f"POL-IMP-{domain_upper}-{i+1:03d}",
            "origin": "implicit",
            "discovery": {
                "confidence": rule["confidence"],
                "support": rule["support_count"],
                "source_log": f"DecisionsDev/{domain}/decisions_{size}.csv",
                "human_validated": False
            },
            "scope": scope,
            "conditions": conditions,
            "actions": actions,
            "exceptions": [],
            "metadata": {
                "source": f"DecisionsDev/{domain}/decisions_{size}.csv (mined)",
                "owner": "TBD",
                "effective_date": None,
                "domain": domain,
                "regulatory_linkage": []
            }
        }
        policies.append(policy)

    return policies


# ---------------------------------------------------------------------------
# Step 5: Evaluate
# ---------------------------------------------------------------------------
def evaluate_decision_accuracy(
    rules: list[dict],
    df: pd.DataFrame,
    decision_col: str,
) -> dict:
    """Apply discovered rules to each row, check prediction accuracy."""
    correct = 0
    covered = 0
    total = len(df)

    for _, row in df.iterrows():
        row_items = set()
        for col in df.columns:
            val = row[col]
            if pd.notna(val) and val is not None:
                row_items.add(str(val))

        predicted = None
        for rule in rules:
            ant_set = set(rule["antecedent"])
            if ant_set.issubset(row_items):
                for cons in rule["consequent"]:
                    if cons.startswith(f"{decision_col}="):
                        predicted = cons
                        break
                if predicted:
                    break

        if predicted is not None:
            covered += 1
            actual = str(row[decision_col])
            if predicted == actual:
                correct += 1

    coverage = covered / total if total > 0 else 0
    accuracy = correct / covered if covered > 0 else 0

    return {
        "total": total,
        "covered": covered,
        "correct": correct,
        "coverage": round(coverage, 4),
        "accuracy_on_covered": round(accuracy, 4),
        "overall_accuracy": round(correct / total, 4) if total > 0 else 0,
    }


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------
def run_domain(domain: str, size: str, min_conf: float, min_sup: float) -> dict:
    config = load_config()
    dc = config["domains"][domain]
    decision_col = dc["decision_variable"]
    secondary = dc.get("secondary_decisions", [])
    all_decision_cols = [decision_col] + secondary

    print(f"\n{'='*60}")
    print(f"Domain: {domain} | Size: {size}")
    print(f"Decision col: {decision_col} | Secondary: {secondary}")
    print(f"{'='*60}")

    # Load
    df = load_flat_data(domain, size)
    print(f"  Value distribution for {decision_col}:")
    print(f"    {df[decision_col].value_counts().to_dict()}")

    # Discretize
    print("  Discretizing...")
    disc_df, input_cols = discretize(df, all_decision_cols + ["reason"])
    print(f"  Input columns ({len(input_cols)}): {input_cols}")

    # Mine rules
    rules = run_fpgrowth(
        disc_df,
        input_cols=input_cols,
        decision_cols=all_decision_cols,
        min_support_ratio=min_sup,
        min_confidence=min_conf,
    )

    if not rules:
        print("  No rules found! Try --min-confidence 0.7 or --size large")
        return {"domain": domain, "size": size, "n_rules": 0, "error": "no_rules"}

    # Print top rules
    print(f"\n  Top 10 rules:")
    for r in rules[:10]:
        ant = " ∧ ".join(r["antecedent"])
        cons = " → ".join(r["consequent"])
        print(f"    [conf={r['confidence']:.2f} lift={r['lift']:.2f}] {ant}  →  {cons}")

    # Convert to Stage 1 JSON
    policies = rules_to_stage1_json(rules, domain, size)

    # Save
    out_dir = RESULTS_DIR / "task1_extraction" / domain
    out_dir.mkdir(parents=True, exist_ok=True)

    rules_path = out_dir / f"implicit_rules_{size}.json"
    with open(rules_path, "w") as f:
        json.dump(rules, f, indent=2)

    policies_path = out_dir / f"implicit_policies_{size}.json"
    with open(policies_path, "w") as f:
        json.dump(policies, f, indent=2, ensure_ascii=False)

    print(f"\n  Saved {len(rules)} rules → {rules_path.name}")
    print(f"  Saved {len(policies)} Stage 1 policies → {policies_path.name}")

    # Evaluate
    print("\n  Evaluating decision accuracy...")
    eval_result = evaluate_decision_accuracy(rules, disc_df, decision_col)
    print(f"    Coverage:  {eval_result['coverage']:.1%}")
    print(f"    Accuracy:  {eval_result['accuracy_on_covered']:.1%} (on covered)")
    print(f"    Overall:   {eval_result['overall_accuracy']:.1%}")

    return {
        "domain": domain,
        "size": size,
        "n_rules": len(rules),
        "top_confidence": rules[0]["confidence"],
        "top_lift": rules[0]["lift"],
        "evaluation": eval_result,
    }


def main():
    parser = argparse.ArgumentParser(description="Implicit policy evaluation (v2)")
    parser.add_argument("--domain", type=str, default="all")
    parser.add_argument("--size", type=str, default="small", choices=["small", "large"])
    parser.add_argument("--min-confidence", type=float, default=0.8)
    parser.add_argument("--min-support", type=float, default=0.05)
    args = parser.parse_args()

    targets = DOMAINS if args.domain == "all" else [args.domain]
    all_results = []

    for domain in targets:
        try:
            result = run_domain(domain, args.size, args.min_confidence, args.min_support)
            all_results.append(result)
        except FileNotFoundError as e:
            print(f"  [SKIP] {domain}: {e}")
        except Exception as e:
            print(f"  [ERROR] {domain}: {e}")
            import traceback
            traceback.print_exc()

    out = RESULTS_DIR / "implicit_eval_results.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\n  All results → {out}")


if __name__ == "__main__":
    main()
