#!/usr/bin/env python3
"""
04_annotation_agreement.py

Compute inter-annotator agreement for extraction and conflict annotations.
Reports Cohen's κ (pairwise) and Fleiss' κ (all annotators).

Usage:
    python scripts/04_annotation_agreement.py
    python scripts/04_annotation_agreement.py --task extraction
    python scripts/04_annotation_agreement.py --task conflict
"""

import argparse
import json
import itertools
from pathlib import Path
from collections import Counter

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
ANNOTATION_DIR = ROOT / "annotation"


# ---------------------------------------------------------------------------
# Cohen's Kappa (pairwise, 2 annotators)
# ---------------------------------------------------------------------------
def cohens_kappa(labels1: list, labels2: list) -> float:
    """Compute Cohen's kappa for two annotators."""
    assert len(labels1) == len(labels2), "Label lists must be same length"
    n = len(labels1)
    if n == 0:
        return 0.0

    # Observed agreement
    p_o = sum(1 for a, b in zip(labels1, labels2) if a == b) / n

    # Expected agreement by chance
    all_labels = set(labels1) | set(labels2)
    p_e = 0.0
    for label in all_labels:
        p1 = labels1.count(label) / n
        p2 = labels2.count(label) / n
        p_e += p1 * p2

    if p_e == 1.0:
        return 1.0

    return (p_o - p_e) / (1 - p_e)


# ---------------------------------------------------------------------------
# Fleiss' Kappa (multiple annotators)
# ---------------------------------------------------------------------------
def fleiss_kappa(ratings_matrix: np.ndarray) -> float:
    """
    Compute Fleiss' kappa for multiple annotators.
    ratings_matrix: (n_items x n_categories) matrix where each cell is
                    the number of annotators who assigned that category.
    """
    n_items, n_cats = ratings_matrix.shape
    n_raters = int(ratings_matrix[0].sum())

    if n_items == 0 or n_raters <= 1:
        return 0.0

    # P_i for each item
    P_i = np.zeros(n_items)
    for i in range(n_items):
        row = ratings_matrix[i]
        P_i[i] = (np.sum(row ** 2) - n_raters) / (n_raters * (n_raters - 1))

    P_bar = np.mean(P_i)

    # P_j for each category
    p_j = np.sum(ratings_matrix, axis=0) / (n_items * n_raters)
    P_e = np.sum(p_j ** 2)

    if P_e == 1.0:
        return 1.0

    return (P_bar - P_e) / (1 - P_e)


# ---------------------------------------------------------------------------
# Extraction Agreement
# ---------------------------------------------------------------------------
def compute_extraction_agreement() -> dict:
    """
    Measure agreement on extraction annotations.

    For extraction, agreement is measured at the policy-component level:
    - For each document section, did annotators agree on the same components?
    - Simplified to binary: did annotator mark this span as containing a policy? (yes/no)
    - And per-component: did they agree on scope, conditions, actions, exceptions?
    """
    anno_dir = ANNOTATION_DIR / "extraction_annotations"
    if not anno_dir.exists():
        print("  [WARN] No extraction annotations found")
        return {"status": "no_data"}

    # Group annotations by annotator
    annotator_files = sorted(anno_dir.glob("*.jsonl"))
    if len(annotator_files) < 2:
        print("  [WARN] Need at least 2 annotator files")
        return {"status": "insufficient_annotators"}

    # Load all annotations grouped by (company, doc_id, section)
    all_annotations = {}  # {annotator_id: {(company, doc_id, section): labels}}

    for f in annotator_files:
        anno_id = f.stem.split("_")[-1]  # e.g., "jetblue_annotator1" → "annotator1"
        company = f.stem.rsplit("_", 1)[0]
        all_annotations.setdefault(anno_id, {})

        with open(f) as fh:
            for line in fh:
                line = line.strip()
                if line:
                    item = json.loads(line)
                    for policy in item.get("policies", []):
                        key = (company, item.get("doc_id", ""), policy.get("section", ""))
                        components = policy.get("components", {})
                        # Binary: does this component exist?
                        label = {
                            "has_scope": bool(components.get("scope")),
                            "has_conditions": bool(components.get("conditions")),
                            "has_actions": bool(components.get("actions")),
                            "has_exceptions": bool(components.get("exceptions")),
                        }
                        all_annotations[anno_id][key] = label

    return _compute_pairwise_and_fleiss(all_annotations, "extraction")


# ---------------------------------------------------------------------------
# Conflict Agreement
# ---------------------------------------------------------------------------
def compute_conflict_agreement() -> dict:
    """
    Measure agreement on conflict annotations.
    Binary task: does this pair have a conflict? (1/0)
    """
    anno_dir = ANNOTATION_DIR / "conflict_annotations"
    if not anno_dir.exists():
        print("  [WARN] No conflict annotations found")
        return {"status": "no_data"}

    # Load all annotator labels per pair
    pair_labels = {}  # {pair_id: {annotator_id: label}}

    for f in sorted(anno_dir.glob("*.jsonl")):
        with open(f) as fh:
            for line in fh:
                line = line.strip()
                if line:
                    item = json.loads(line)
                    pair_id = item.get("pair_id", "")
                    anno_id = str(item.get("annotator_id", f.stem))
                    label = int(item.get("has_conflict", 0))
                    pair_labels.setdefault(pair_id, {})[anno_id] = label

    if not pair_labels:
        return {"status": "no_data"}

    # Get annotator IDs
    all_annotators = set()
    for labels in pair_labels.values():
        all_annotators.update(labels.keys())
    annotator_list = sorted(all_annotators)

    if len(annotator_list) < 2:
        return {"status": "insufficient_annotators"}

    # Pairwise Cohen's κ
    pairwise_results = []
    for a1, a2 in itertools.combinations(annotator_list, 2):
        labels1 = []
        labels2 = []
        for pair_id, labels in pair_labels.items():
            if a1 in labels and a2 in labels:
                labels1.append(labels[a1])
                labels2.append(labels[a2])

        if labels1:
            kappa = cohens_kappa(labels1, labels2)
            pairwise_results.append({
                "annotators": [a1, a2],
                "n_items": len(labels1),
                "kappa": round(kappa, 4),
                "agreement_pct": round(sum(1 for a, b in zip(labels1, labels2) if a == b) / len(labels1) * 100, 1),
            })

    # Fleiss' κ (all annotators)
    n_pairs = len(pair_labels)
    ratings = np.zeros((n_pairs, 2))  # 2 categories: conflict / no-conflict

    for i, (pair_id, labels) in enumerate(pair_labels.items()):
        for anno_id in annotator_list:
            if anno_id in labels:
                ratings[i, labels[anno_id]] += 1

    fleiss_k = fleiss_kappa(ratings)

    avg_pairwise = (
        sum(r["kappa"] for r in pairwise_results) / len(pairwise_results)
        if pairwise_results else 0.0
    )

    return {
        "task": "conflict",
        "n_annotators": len(annotator_list),
        "n_pairs": n_pairs,
        "pairwise_cohens_kappa": pairwise_results,
        "avg_cohens_kappa": round(avg_pairwise, 4),
        "fleiss_kappa": round(fleiss_k, 4),
        "target_kappa": 0.74,
        "meets_target": avg_pairwise >= 0.74,
    }


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------
def _compute_pairwise_and_fleiss(all_annotations: dict, task_name: str) -> dict:
    """Generic pairwise + Fleiss computation for binary labels."""
    annotator_ids = sorted(all_annotations.keys())

    if len(annotator_ids) < 2:
        return {"status": "insufficient_annotators"}

    # Get common keys
    common_keys = set.intersection(*(set(a.keys()) for a in all_annotations.values()))
    if not common_keys:
        return {"status": "no_common_items"}

    # For extraction: flatten component labels into a single agree/disagree
    pairwise_results = []
    for a1, a2 in itertools.combinations(annotator_ids, 2):
        labels1 = []
        labels2 = []
        for key in sorted(common_keys):
            l1 = all_annotations[a1].get(key, {})
            l2 = all_annotations[a2].get(key, {})
            # Flatten: tuple of component presence
            labels1.append(str(sorted(l1.items())))
            labels2.append(str(sorted(l2.items())))

        kappa = cohens_kappa(labels1, labels2)
        pairwise_results.append({
            "annotators": [a1, a2],
            "n_items": len(labels1),
            "kappa": round(kappa, 4),
        })

    avg_kappa = sum(r["kappa"] for r in pairwise_results) / len(pairwise_results)

    return {
        "task": task_name,
        "n_annotators": len(annotator_ids),
        "n_items": len(common_keys),
        "pairwise_cohens_kappa": pairwise_results,
        "avg_cohens_kappa": round(avg_kappa, 4),
        "target_kappa": 0.78 if task_name == "extraction" else 0.74,
        "meets_target": avg_kappa >= (0.78 if task_name == "extraction" else 0.74),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Inter-Annotator Agreement")
    parser.add_argument("--task", choices=["extraction", "conflict", "all"], default="all")
    args = parser.parse_args()

    results = {}

    if args.task in ("extraction", "all"):
        print("\n" + "=" * 50)
        print("EXTRACTION AGREEMENT")
        print("=" * 50)
        extraction_result = compute_extraction_agreement()
        results["extraction"] = extraction_result
        if "avg_cohens_kappa" in extraction_result:
            print(f"  Avg Cohen's κ: {extraction_result['avg_cohens_kappa']}")
            print(f"  Target: ≥ 0.78  {'✓ MET' if extraction_result['meets_target'] else '✗ NOT MET'}")

    if args.task in ("conflict", "all"):
        print("\n" + "=" * 50)
        print("CONFLICT AGREEMENT")
        print("=" * 50)
        conflict_result = compute_conflict_agreement()
        results["conflict"] = conflict_result
        if "avg_cohens_kappa" in conflict_result:
            print(f"  Avg Cohen's κ: {conflict_result['avg_cohens_kappa']}")
            print(f"  Fleiss' κ:     {conflict_result['fleiss_kappa']}")
            print(f"  Target: ≥ 0.74  {'✓ MET' if conflict_result['meets_target'] else '✗ NOT MET'}")

    # Save
    output_path = ANNOTATION_DIR / "agreement_results.json"
    with open(output_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to {output_path}")


if __name__ == "__main__":
    main()
