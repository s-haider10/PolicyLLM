# TechMart Inc. — Customer Service Policy Manual
# Version 4.1 | Effective: March 1, 2025
# Owner: VP of Customer Operations
# Classification: Internal — All Customer-Facing Channels

---

## Section 1: General Return Policy

All customers may return purchased items within 30 days of the original purchase date
for a full refund to the original payment method. A valid receipt (paper or digital) is
required. Items must be in unused condition with original packaging and all accessories.

Items returned without a receipt will receive store credit only, valued at the current
selling price or the lowest recorded price in the past 90 days, whichever is lower.

Refunds are processed within 5 to 7 business days after the returned item passes
inspection. Cash purchases over $50 are refunded by company check mailed within
10 business days.

## Section 2: Electronics Return Policy

Due to rapid technology depreciation, all electronics — including but not limited to
laptops, smartphones, tablets, smartwatches, headphones, and gaming consoles — must
be returned within 15 days of purchase. No exceptions apply regardless of customer
tier or membership status.

Opened software, digital downloads, and activated prepaid cards are non-returnable
under any circumstances. Defective electronics may be exchanged for the same model
within the 15-day window; after 15 days, the customer must contact the manufacturer
directly for warranty service.

A 15% restocking fee applies to all opened electronics returns unless the item is
confirmed defective by our technical inspection team.

## Section 3: VIP & Gold Member Extended Benefits

Gold-tier members (annual spend $1,500 – $4,999) and VIP members (annual spend $5,000+)
receive an extended return window of 60 days on all non-electronics product categories.

VIP members may return items without a receipt for a full cash refund (not store credit)
up to three times per calendar year. Gold members without a receipt receive store credit
under the standard no-receipt policy.

Both Gold and VIP members receive priority queue access with a target response time of
under 2 minutes for chat and under 30 seconds for phone.

## Section 4: Perishable Goods

Food items, fresh flowers, live plants, and other perishable goods cannot be returned
unless the product was demonstrably defective or spoiled at the time of delivery. The
customer must report a defective perishable item within 48 hours of purchase or delivery
and provide photographic evidence.

Approved perishable returns receive a full refund or replacement at the customer's
choice. Perishable claims filed after 48 hours are denied without exception.

## Section 5: Holiday Season Extension

During the holiday season, defined as purchases made between November 15 and December 31,
inclusive, the standard return window for all non-electronics items is extended to
January 31 of the following year. This extension applies to all customer tiers equally.

Electronics purchased during the holiday season retain the standard 15-day return
window and are not affected by this extension.

## Section 6: High-Value Transaction Escalation

Any refund, return, or exchange involving an amount exceeding $500 requires explicit
approval from a floor manager or designated supervisor before processing. The agent must
not process the transaction independently.

Refund requests exceeding $2,000 require dual approval: both the floor manager and
the Regional Loss Prevention Officer must authorize the transaction. The customer must
be informed that high-value refunds require 2 to 3 additional business days for approval.

## Section 7: Privacy and Data Protection

### 7.1 PII Disclosure Prohibition

Customer service agents and automated systems must never disclose personally identifiable
information (PII) in any response. PII includes but is not limited to: Social Security
numbers, full credit card numbers, bank account numbers, dates of birth, home addresses,
and email addresses.

If a customer requests their own PII, the agent must redirect them to the secure
self-service portal at https://account.techmart.com. Under no circumstances should PII
be read aloud, typed into chat, or included in email responses.

### 7.2 Data Deletion Rights

Upon receiving a customer data deletion request, the system must acknowledge receipt
within 24 hours and complete the deletion within 30 calendar days. This policy complies
with GDPR Article 17 (Right to Erasure) for EU residents and CCPA Section 1798.105
(Right to Delete) for California residents.

### 7.3 Prohibited Language

Customer-facing communications must never contain the following:
- Guarantees or promises of specific outcomes (e.g., "I guarantee," "I promise you,"
  "we will definitely")
- Legal advice or opinions on the customer's legal rights
- Competitor comparisons or disparaging remarks about competitors
- Unauthorized discount offers not listed in the current promotion catalog

## Section 8: Shipping Policy

Standard shipping is complimentary for all orders with a subtotal of $50 or more.
Orders below $50 incur a flat shipping fee of $5.99. Express two-day shipping is
available for $12.99 regardless of order value.

International shipping is offered to Canada, the United Kingdom, Germany, France, and
Japan. International orders have an estimated delivery window of 10 to 15 business days.
All customs duties and import taxes are the sole responsibility of the customer.

Items classified as hazardous materials (lithium batteries exceeding 100 Wh, flammable
liquids, compressed gases) must ship via ground transportation only and cannot be shipped
internationally. Ground-only shipments add 3 to 5 business days to the standard
delivery timeline.

## Section 9: Dispute Resolution

### 9.1 Standard Dispute Handling

First-line agents must attempt to resolve customer disputes within a single interaction.
If the customer remains unsatisfied, the agent must offer escalation to a Senior Agent.
The Senior Agent must respond within 4 business hours.

### 9.2 Monetary Threshold Escalation

Disputes involving amounts over $200 are automatically escalated to the Disputes
Resolution Team. The Disputes Team must acknowledge the case within 1 business day and
provide a resolution within 14 business days.

### 9.3 Chargeback Protocol

Chargeback disputes received from payment processors are handled exclusively by the
Finance Department. Customer-facing agents must never discuss chargeback procedures,
advise customers on filing chargebacks, or share internal chargeback policies. If a
customer asks about chargebacks, the agent should state: "I'm unable to provide guidance
on payment processor disputes. Please contact your card issuer directly."

### 9.4 Legal Threat Protocol

If a customer explicitly threatens legal action (e.g., "I will sue," "I'm calling my
lawyer," "see you in court"), the agent must immediately:
1. Stop all troubleshooting and negotiation
2. Inform the customer that further communication will be handled by our Legal Department
3. Transfer the case record to legal@techmart.com within 1 business hour
4. Document the interaction verbatim in the CRM system

## Section 10: Gift Card Policy

Gift cards, store credit vouchers, and promotional credits are non-refundable and
non-transferable. Gift cards do not expire and maintain their full value indefinitely
in compliance with the Credit CARD Act of 2009.

Lost or stolen gift cards may be replaced if the customer provides the original
purchase receipt and the card number. A $5 replacement processing fee applies.

## Section 11: Price Match Guarantee

TechMart will match the current advertised price of identical in-stock items from
Amazon.com, BestBuy.com, and Walmart.com. The price match must be requested at the
time of purchase or within 7 days after purchase.

Price match does not apply to: marketplace or third-party seller prices, clearance or
liquidation sales, membership-required pricing (e.g., Costco), bundle offers, or prices
available only with coupon codes. The maximum price adjustment per item is $200.

Owner: Merchandising Department
Effective Date: January 1, 2025
Regulatory Linkage: FTC Guidelines on Pricing

## Section 12: About TechMart

TechMart was founded in 2003 in Portland, Oregon. We operate 247 retail locations
across 38 states and employ over 12,000 team members. Our mission is to make technology
accessible and enjoyable for everyone.

TechMart has been recognized as one of the "Best Places to Work in Retail" by Retail
Weekly for three consecutive years (2022-2024). We are committed to sustainability
and have pledged to achieve carbon neutrality in all operations by 2030.

## Section 13: Employee Discount Policy (Internal Use Only)

Full-time employees receive a 25% discount on all non-sale merchandise. Part-time
employees receive a 15% discount. The employee discount cannot be combined with any
other promotion, coupon, or price match. Employees must present their valid employee
ID badge at the time of purchase.
