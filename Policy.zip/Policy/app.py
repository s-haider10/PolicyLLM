"""
app.py — PolicyLLM Chainlit Chat Interface

Every user message goes through the full enforcement pipeline:
  Pre-Gen → During-Gen (scaffold) → LLM generation → Post-Gen (regex/Z3/judge)

Usage:
    pip install chainlit
    chainlit run app.py
"""
import json
import os
import sys
import time
from pathlib import Path

import chainlit as cl
from openai import OpenAI

sys.path.insert(0, str(Path(__file__).parent))

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from Enforcement import load_bundle, enforce
from Enforcement.orchestrator import EnforcementConfig
from Extractor.src.llm.client import LLMClient

# ── Config ──────────────────────────────────────────────────
BUNDLE_PATH = os.environ.get(
    "POLICYLLM_BUNDLE",
    "Evaluation/results/synthetic_run/compiled_policy_bundle.json",
)
MODEL = os.environ.get("POLICYLLM_MODEL", "gpt-4o-mini")

BASE_SYSTEM_PROMPT = """You are a TechMart customer service assistant.
Be helpful, concise, and professional.
Always follow company policies when answering customer questions.
If you are unsure about a policy, say so rather than guessing."""


# ── Helpers ─────────────────────────────────────────────────
def make_generate_fn(openai_client: OpenAI, model: str):
    """Returns a callable that the enforcer uses to generate plain-text responses."""
    def _generate(prompt: dict) -> str:
        messages = []
        system = prompt.get("system", "")
        user = prompt.get("user", "")

        if system:
            messages.append({"role": "system", "content": BASE_SYSTEM_PROMPT + "\n\n" + system})
        else:
            messages.append({"role": "system", "content": BASE_SYSTEM_PROMPT})

        messages.append({"role": "user", "content": user})

        resp = openai_client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=0.2,
            max_tokens=1024,
        )
        return resp.choices[0].message.content or ""
    return _generate


def score_color(score: float) -> str:
    if score >= 0.95:
        return "🟢"
    elif score >= 0.85:
        return "🟡"
    elif score >= 0.70:
        return "🟠"
    return "🔴"


def action_label(action: str) -> str:
    labels = {
        "pass": "✅ PASS",
        "auto_correct": "🔧 AUTO-CORRECTED",
        "regenerate": "♻️ REGENERATED",
        "escalate": "🚨 ESCALATED",
    }
    return labels.get(action.lower(), action.upper())


# ── Chainlit Lifecycle ──────────────────────────────────────
@cl.on_chat_start
async def on_start():
    """Load bundle and initialize clients once per session."""
    if not os.path.exists(BUNDLE_PATH):
        await cl.Message(
            content=(
                f"⚠️ Policy bundle not found at `{BUNDLE_PATH}`.\n\n"
                "Run the pipeline first:\n"
                "```bash\n"
                "python run_synthetic_experiment.py --all\n"
                "```\n"
                "Or set `POLICYLLM_BUNDLE` env var to your bundle path."
            )
        ).send()
        return

    # Load bundle
    bundle, index = load_bundle(BUNDLE_PATH)
    meta = json.load(open(BUNDLE_PATH)).get("bundle_metadata", {})

    # Initialize clients
    openai_client = OpenAI()
    llm_client = LLMClient(
        provider="chatgpt", model_id=MODEL, temperature=0.2, max_tokens=1024
    )
    generate_fn = make_generate_fn(openai_client, MODEL)
    config = EnforcementConfig()

    # Store in session
    cl.user_session.set("bundle", bundle)
    cl.user_session.set("index", index)
    cl.user_session.set("llm_client", llm_client)
    cl.user_session.set("generate_fn", generate_fn)
    cl.user_session.set("config", config)

    await cl.Message(
        content=(
            "👋 **TechMart Customer Service**\n\n"
            f"Policy bundle loaded: {meta.get('rule_count', '?')} rules, "
            f"{meta.get('constraint_count', '?')} constraints, "
            f"{meta.get('path_count', '?')} paths.\n\n"
            f"Model: `{MODEL}`\n\n"
            "Every response is verified against company policy in real time.\n"
            "Ask me anything about returns, shipping, loyalty, or your account!"
        )
    ).send()


@cl.on_message
async def on_message(message: cl.Message):
    """Process each user message through the enforcement pipeline."""
    bundle = cl.user_session.get("bundle")
    if bundle is None:
        await cl.Message(content="❌ No policy bundle loaded. Restart the chat.").send()
        return

    index = cl.user_session.get("index")
    llm_client = cl.user_session.get("llm_client")
    generate_fn = cl.user_session.get("generate_fn")
    config = cl.user_session.get("config")

    user_query = message.content

    # Show thinking indicator
    msg = cl.Message(content="")
    await msg.send()

    t0 = time.time()

    try:
        decision = enforce(
            query=user_query,
            bundle=bundle,
            bundle_index=index,
            llm_client=llm_client,
            config=config,
            generate_fn=generate_fn,
        )
    except Exception as e:
        await msg.update(content=f"❌ Error: {e}")
        return

    latency = int((time.time() - t0) * 1000)
    action = decision.action.value.lower()
    score = decision.score
    violations = decision.violations

    # Build response based on action
    if action == "pass":
        response_text = decision.corrected_response or decision.llm_response
        footer = f"\n\n---\n{score_color(score)} {action_label(action)} · score {score:.2f} · {latency}ms"
        await msg.update(content=response_text + footer)

    elif action == "auto_correct":
        response_text = decision.corrected_response or decision.llm_response
        fix_note = f"_Auto-corrected: {violations[0]}_" if violations else ""
        footer = f"\n\n---\n{score_color(score)} {action_label(action)} · score {score:.2f} · {latency}ms\n{fix_note}"
        await msg.update(content=response_text + footer)

    elif action == "escalate":
        escalate_reasons = "\n".join(f"- {v}" for v in violations[:3]) if violations else "Policy violation detected."
        await msg.update(
            content=(
                "I'm unable to help with that request. "
                "Let me transfer you to a specialist.\n\n"
                f"---\n{score_color(score)} {action_label(action)} · score {score:.2f} · {latency}ms\n\n"
                f"**Reasons:**\n{escalate_reasons}"
            )
        )

    elif action == "regenerate":
        response_text = decision.corrected_response or decision.llm_response
        if response_text:
            footer = f"\n\n---\n{score_color(score)} {action_label(action)} · score {score:.2f} · {latency}ms"
            await msg.update(content=response_text + footer)
        else:
            await msg.update(
                content=(
                    "I apologize, I'm having trouble answering that within policy guidelines. "
                    "Let me connect you with a colleague.\n\n"
                    f"---\n{score_color(score)} {action_label(action)} · score {score:.2f} · {latency}ms"
                )
            )
